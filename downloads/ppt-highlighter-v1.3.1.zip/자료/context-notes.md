﻿# v1.3.1 context notes
User approved highlighter icon opening a visual palette instead of a text dropdown; removed external HEX edit. Other colors contains HEX and RGB dialog; eyedropper samples a screen pixel and cancels with Escape/right click.
Previous releases preserved. Core engine sources unchanged from v1.2.1. Custom icon and swatch callbacks return cached COM pictures; dispose at add-in shutdown. Screen capture lives only in picker memory, and is released on close; no network or screenshot file output.
Explorer user execution context must be used for installation and normal restart. Codex process registry/file views differ from Explorer even for identical path strings.
Microsoft RibbonX gallery reference: https://learn.microsoft.com/en-us/openspecs/office_standards/ms-customui/017f9f94-700f-4846-ba19-c695ad32929f
Runtime visual checks and release status are documented in the project's ribbon-v1.3.1/verification.md.

Version 1.3.1: Office-style two-tab color dialog implemented by the addin; Microsoft built-in dialog is not invoked. RGB/HEX and hue/saturation/brightness controls synchronize. Original current-color preview remains unchanged until confirmation.

Candidate03 corrects owner resolution: Application.HWND was unavailable and silently fell back to zero. Resolve the current PowerPoint process root owner via Win32, require a valid owner, and place after layout in its monitor work area. Numeric input uses Segoe UI and ImeMode.Disable on RGB/HEX edit controls.
