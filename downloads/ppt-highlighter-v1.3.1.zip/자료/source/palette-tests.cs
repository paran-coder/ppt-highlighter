using System;
using System.Drawing;
using System.Xml.Linq;
using System.Linq;
using PptHighlighter;
class PaletteTests {
 static int count;static void Check(bool value,string name){if(!value)throw new Exception(name);count++;Console.WriteLine("PASS "+name);}
 [STAThread]static int Main(){try{var c=new Connect();int initial;Check(PaletteColor.TryHex("#FFE865",out initial)&&initial==0x65E8FF,"default Office RGB conversion");int v;foreach(string bad in new[]{"#abc","ZZZZZZ",null,"#1234567","-12345"})Check(!PaletteColor.TryHex(bad,out v),"invalid HEX "+bad);Check(PaletteColor.TryHex(" 123456 ",out v)&&PaletteColor.Hex(v)=="#123456","trimmed custom HEX roundtrip");Check(c.GetColorCount(null)==20,"twenty visual palette colors");for(int i=0;i<c.GetColorCount(null);i++){c.ChooseColor(null,"",i);int rgb;Check(PaletteColor.TryHex(c.GetValue(new Control("phHex")),out rgb),"palette color HEX "+i);Check(c.GetSelectedColor(null)==i,"palette selection "+i);using(Bitmap swatch=PaletteColor.Swatch(rgb))Check(swatch.GetPixel(12,12).ToArgb()==PaletteColor.FromOffice(rgb).ToArgb(),"swatch pixel "+i);using(Bitmap icon=PaletteColor.Icon(rgb))Check(icon.GetPixel(16,29).ToArgb()==PaletteColor.FromOffice(rgb).ToArgb(),"icon underline "+i);Check(c.GetColorImage(null,i)!=null,"COM picture "+i);}
 string before=c.GetValue(new Control("phHex"));c.ChooseColor(null,"",-1);Check(c.GetValue(new Control("phHex"))==before,"invalid gallery index preserves color");c.ChooseColor(null,"",100);Check(c.GetValue(new Control("phHex"))==before,"overflow gallery index preserves color");Check(c.GetColorIcon(null)!=null,"COM icon picture");Array custom=null;c.OnBeginShutdown(ref custom);c.OnBeginShutdown(ref custom);Check(true,"image cleanup is idempotent");Console.WriteLine("PASS "+count+" checks");return 0;}catch(Exception ex){Console.WriteLine(ex);return 1;}}
}
public sealed class Control {public string Id{get;set;}public Control(string id){Id=id;}}
