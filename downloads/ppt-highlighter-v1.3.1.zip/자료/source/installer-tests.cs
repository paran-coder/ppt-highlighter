﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Xml.Linq;
class InstallerTests {
 static Type type;static int passed;
 static void Field(string key,object value){type.GetField(key,BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic).SetValue(null,value);}
 static void Fixture(string folder,string version,bool badHash,bool extra){Directory.CreateDirectory(folder);string exe=Path.Combine(folder,"Uninstall.exe");File.WriteAllText(exe,"owned test uninstaller");string hash;using(var h=SHA256.Create())hash=BitConverter.ToString(h.ComputeHash(File.ReadAllBytes(exe))).Replace("-","");new XDocument(new XElement("Removed",new XAttribute("Owner",folder),new XAttribute("Version",version),new XAttribute("UninstallerSHA256",badHash?"BAD":hash))).Save(Path.Combine(folder,"removed.xml"));if(extra)File.WriteAllText(Path.Combine(folder,"keep.txt"),"must remain");Field("Base",folder);Field("Uninstaller",exe);}
 static void Check(bool ok,string name){if(!ok)throw new Exception(name);passed++;Console.WriteLine("PASS "+name);}
 static bool Cleanup(){try{type.GetMethod("CleanupRemovedInstallation",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,null);return true;}catch(TargetInvocationException){return false;}}
 static int Main(string[] args){try{type=Assembly.LoadFrom(args[0]).GetType("Installation");if(Directory.Exists(args[1]))throw new Exception("Evidence exists");Directory.CreateDirectory(args[1]);Field("Keys",new[]{@"Software\PptHighlighterFixtureProbe\"+Guid.NewGuid().ToString("N")});foreach(string v in new[]{"1.1.0","1.2.0","1.2.1","1.3.0","1.3.1"}){string p=Path.Combine(args[1],"version-"+v);Fixture(p,v,false,false);Check(Cleanup()&&!Directory.Exists(p),"owned removed record "+v);}string unknown=Path.Combine(args[1],"unknown");Fixture(unknown,"0.9.0",false,false);Check(!Cleanup()&&File.Exists(Path.Combine(unknown,"Uninstall.exe")),"reject unknown version");string changed=Path.Combine(args[1],"changed");Fixture(changed,"1.1.0",true,false);Check(!Cleanup()&&File.Exists(Path.Combine(changed,"Uninstall.exe")),"reject changed uninstaller");string extra=Path.Combine(args[1],"extra");Fixture(extra,"1.1.0",false,true);Check(!Cleanup()&&File.Exists(Path.Combine(extra,"keep.txt")),"preserve unrelated file");Console.WriteLine("PASS "+passed+" checks");return 0;}catch(Exception e){Console.WriteLine(e);return 1;}}
}

