using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace PptHighlighter {
    public sealed class EngineController : IDisposable {
        static readonly Guid EventsId=new Guid("914934C2-5A91-11CF-8700-00AA0060263B");
        public readonly HighlightEngine Engine;
        object application;
        readonly Timer timer;
        readonly BeforeSaveHandler saveHandler;
        readonly SelectionHandler selectionHandler;
        bool saveAttached,selectionAttached,disposed;
        DateTime deferUntil=DateTime.MinValue;
        public bool EventsAttached { get { return saveAttached; } }
        public bool Enabled { get { return timer.Enabled; } set { timer.Enabled=value; } }
        public delegate void BeforeSaveHandler([MarshalAs(UnmanagedType.IDispatch)] object presentation, ref bool cancel);
        public delegate void SelectionHandler([MarshalAs(UnmanagedType.IDispatch)] object selection);
        public EngineController(object app) {
            application=app;Engine=new HighlightEngine(app);
            saveHandler=BeforeSave;selectionHandler=SelectionChanged;
            try { ComEventsHelper.Combine(app,EventsId,2018,saveHandler);saveAttached=true; }
            catch(Exception ex){Engine.SetStatus("저장 전 자동 갱신 연결 실패: "+ex.Message);}
            try { ComEventsHelper.Combine(app,EventsId,2001,selectionHandler);selectionAttached=true; }catch(COMException){}
            timer=new Timer();timer.Interval=300;timer.Tick+=Tick;timer.Start();
        }
        void SelectionChanged(object selection) { /* Timer coalesces selection and edit notifications. */ }
        void BeforeSave(object presentation,ref bool cancel) {
            try { Engine.SyncPresentation(presentation); }
            catch(Exception ex){Engine.SetStatus("저장 전 강조 갱신 실패: "+ex.Message);MessageBox.Show("강조 위치를 갱신하지 못했습니다. 저장 후 '다시 맞추기'로 확인하세요.\n"+ex.Message,"PPT Highlighter");}
        }
        void Tick(object sender,EventArgs e) {
            if(disposed)return;
            // Give IME composition and common Undo/Redo keyboard operations a quiet interval.
            if(NativeInput.Composing() || NativeInput.UndoKeys()){deferUntil=DateTime.UtcNow.AddMilliseconds(700);return;}
            if(DateTime.UtcNow<deferUntil)return;
            try { Engine.SyncActive(); }
            catch(COMException ex){Engine.SetStatus("PowerPoint 응답 대기 · "+ex.Message);}
            catch(Exception ex){Engine.SetStatus("자동 갱신 확인 필요 · "+ex.Message);}
        }
        public void Dispose() {
            if(disposed)return;disposed=true;timer.Stop();timer.Dispose();
            if(saveAttached)try{ComEventsHelper.Remove(application,EventsId,2018,saveHandler);}catch(COMException){}
            if(selectionAttached)try{ComEventsHelper.Remove(application,EventsId,2001,selectionHandler);}catch(COMException){}
            Engine.Dispose();application=null;
        }
    }
    static class NativeInput {
        [StructLayout(LayoutKind.Sequential)] struct GuiInfo {public int Size,Flags;public IntPtr Active,Focus,Capture,MenuOwner,MoveSize,Caret;public Rectangle CaretRect;}
        [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint id,ref GuiInfo info);
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
        [DllImport("imm32.dll")] static extern IntPtr ImmGetContext(IntPtr window);
        [DllImport("imm32.dll")] static extern int ImmGetCompositionStringW(IntPtr context,int index,IntPtr buffer,int length);
        [DllImport("imm32.dll")] static extern bool ImmReleaseContext(IntPtr window,IntPtr context);
        public static bool Composing() {
            var info=new GuiInfo{Size=Marshal.SizeOf(typeof(GuiInfo))};
            if(!GetGUIThreadInfo(0,ref info)||info.Focus==IntPtr.Zero)return false;
            IntPtr context=ImmGetContext(info.Focus);if(context==IntPtr.Zero)return false;
            try{return ImmGetCompositionStringW(context,8,IntPtr.Zero,0)>0;}finally{ImmReleaseContext(info.Focus,context);}
        }
        public static bool UndoKeys(){return (GetAsyncKeyState(0x11)&0x8000)!=0&&((GetAsyncKeyState(0x5A)&0x8000)!=0||(GetAsyncKeyState(0x59)&0x8000)!=0);}
    }
    public sealed class HighlightForm : Form {
        readonly EngineController controller;
        readonly object application;
        readonly NumericUpDown transparency,top,bottom,left,right;
        readonly Label status;
        readonly Button color;
        readonly Panel preview;
        readonly CheckBox automatic;
        public HighlightForm(EngineController controller,object application,bool portable) {
            this.controller=controller;this.application=application;
            Text="PPT Highlighter · v1.1.0";Font=new Font("맑은 고딕",10);ClientSize=new Size(420,610);
            MinimumSize=new Size(436,649);MaximumSize=new Size(620,850);AutoScaleMode=AutoScaleMode.Dpi;
            BackColor=Color.FromArgb(248,249,252);StartPosition=FormStartPosition.CenterScreen;TopMost=portable;
            var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(20),ColumnCount=2,RowCount=12};
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));Controls.Add(layout);
            AddWide(layout,new Label{Text="선택한 글자에 하이라이트",Font=new Font(Font.FontFamily,16,FontStyle.Bold),AutoSize=true},0);
            AddWide(layout,new Label{Text="PowerPoint에서 글자 일부를 드래그한 뒤 적용하세요.",AutoSize=true,ForeColor=Color.DimGray},1);
            color=new Button{Text="색상 선택",BackColor=Color.FromArgb(255,232,101),Dock=DockStyle.Fill,FlatStyle=FlatStyle.Flat};
            color.Click+=delegate {using(var dialog=new ColorDialog{Color=color.BackColor,FullOpen=true})if(dialog.ShowDialog(this)==DialogResult.OK){color.BackColor=dialog.Color;preview.Invalidate();}};
            layout.Controls.Add(new Label{Text="하이라이트 색상",AutoSize=true,Anchor=AnchorStyles.Left},0,2);layout.Controls.Add(color,1,2);
            transparency=Number(layout,"투명도 (%)",35,0,100,3);top=Number(layout,"위 여백 (pt)",1,-72,144,4);
            bottom=Number(layout,"아래 여백 (pt)",1,-72,144,5);left=Number(layout,"왼쪽 여백 (pt)",2,-72,144,6);right=Number(layout,"오른쪽 여백 (pt)",2,-72,144,7);
            preview=new Panel{Height=74,Dock=DockStyle.Fill,BackColor=Color.White};preview.Paint+=Preview;
            AddWide(layout,preview,8);
            var buttons=new FlowLayoutPanel{AutoSize=true,Dock=DockStyle.Fill};
            buttons.Controls.Add(ActionButton("선택 글자에 적용",delegate{controller.Engine.ApplySelection(Style());}));
            buttons.Controls.Add(ActionButton("강조 제거",delegate{controller.Engine.RemoveSelection();}));
            buttons.Controls.Add(ActionButton("다시 맞추기",delegate{controller.Engine.Refresh();}));
            buttons.Controls.Add(ActionButton("예제 열기",delegate{CreateExample();}));AddWide(layout,buttons,9);
            automatic=new CheckBox{Text=portable?"자동 갱신 · 이 창을 열어 두세요":"자동 갱신",Checked=controller.Enabled,AutoSize=true};
            automatic.CheckedChanged+=delegate{controller.Enabled=automatic.Checked;};AddWide(layout,automatic,10);
            status=new Label{Text=controller.Engine.Status,AutoSize=true,MaximumSize=new Size(375,90),ForeColor=Color.FromArgb(45,65,85)};AddWide(layout,status,11);
            controller.Engine.StatusChanged+=StatusUpdated;FormClosed+=delegate{controller.Engine.StatusChanged-=StatusUpdated;};
            for(int i=0;i<layout.RowCount;i++)layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles[8]=new RowStyle(SizeType.Absolute,78);
        }
        void StatusUpdated(object sender,EventArgs e){if(!IsDisposed)status.Text=controller.Engine.Status;}
        static void AddWide(TableLayoutPanel table,Control control,int row){control.Margin=new Padding(0,5,0,9);table.Controls.Add(control,0,row);table.SetColumnSpan(control,2);}
        NumericUpDown Number(TableLayoutPanel table,string label,decimal value,decimal min,decimal max,int row) {
            table.Controls.Add(new Label{Text=label,AutoSize=true,Anchor=AnchorStyles.Left},0,row);
            var input=new NumericUpDown{Value=value,Minimum=min,Maximum=max,DecimalPlaces=1,Increment=0.5M,Dock=DockStyle.Fill};
            input.ValueChanged+=delegate{if(preview!=null)preview.Invalidate();};table.Controls.Add(input,1,row);return input;
        }
        Button ActionButton(string label,Action action) {
            var button=new Button{Text=label,AutoSize=true,Height=34,Padding=new Padding(4),FlatStyle=FlatStyle.Flat};
            button.Click+=delegate{try{action();}catch(Exception ex){controller.Engine.SetStatus(ex.Message);}};return button;
        }
        public void SetStyle(HighlightStyle style){style.Validate();color.BackColor=Color.FromArgb(style.Rgb&255,(style.Rgb>>8)&255,(style.Rgb>>16)&255);transparency.Value=(decimal)(style.Transparency*100);top.Value=(decimal)style.Top;bottom.Value=(decimal)style.Bottom;left.Value=(decimal)style.Left;right.Value=(decimal)style.Right;preview.Invalidate();}
        public HighlightStyle Style(){Color c=color.BackColor;return new HighlightStyle{Rgb=c.R|(c.G<<8)|(c.B<<16),Transparency=(double)transparency.Value/100,Top=(double)top.Value,Bottom=(double)bottom.Value,Left=(double)left.Value,Right=(double)right.Value};}
        void Preview(object sender,PaintEventArgs e) {
            e.Graphics.Clear(Color.White);
            using(var brush=new SolidBrush(Color.FromArgb((int)(255*(1-(double)transparency.Value/100)),color.BackColor)))e.Graphics.FillRectangle(brush,20,17,218,38);
            using(var font=new Font(Font.FontFamily,17))TextRenderer.DrawText(e.Graphics,"선택한 글자  Aa",font,new Point(23,19),Color.FromArgb(28,33,43));
        }
        public void CreateExample() {
            dynamic app=application;dynamic pres=app.Presentations.Add(-1);dynamic slide=pres.Slides.Add(1,12);
            dynamic text=slide.Shapes.AddTextbox(1,55,100,620,230);
            text.TextFrame2.TextRange.Text="문장 중 선택한 글자만 강조합니다.\r글자를 수정하거나 삭제해 보세요.";
            text.TextFrame2.TextRange.Font.Name="맑은 고딕";text.TextFrame2.TextRange.Font.Size=30;
            controller.Engine.ApplyRange(slide,text,5,6,Style());
            text.TextFrame2.TextRange.Characters(6,6).Select();
            controller.Engine.SetStatus("예제를 만들었습니다. PowerPoint에서 글자를 수정해 보세요.");
        }
    }
}
