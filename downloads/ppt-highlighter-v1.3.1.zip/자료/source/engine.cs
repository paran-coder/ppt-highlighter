using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.InteropServices;

namespace PptHighlighter {
    public sealed class HighlightEngine : IDisposable {
        public const string StateTag="PH_STATE_V1", OwnerTag="PH_OWNER_V1", KeyTag="PH_KEY_V1";
        dynamic app;
        bool busy, disposed;
        readonly Dictionary<string,Dictionary<string,string>> history=new Dictionary<string,Dictionary<string,string>>();
        public string Status { get; private set; }
        public event EventHandler StatusChanged;
        public HighlightEngine(object application) { app=application; Status="글자 일부를 선택하고 적용하세요."; }
        void Report(string value) { if(Status!=value){Status=value;if(StatusChanged!=null)StatusChanged(this,EventArgs.Empty);} }
        public void SetStatus(string value) { Report(value); }
        public ShapeState GetState(object source) {
            dynamic shape=source;
            string tag=Tag(shape,StateTag);
            return tag.Length==0?new ShapeState{Text=(string)shape.TextFrame2.TextRange.Text}:StateCodec.Decode(tag);
        }
        static string Tag(dynamic shape,string key) { return (string)shape.Tags.Item(key); }
        static string Identity(dynamic slide,dynamic shape) { return (string)slide.Parent.FullName+"|"+slide.SlideID+"|"+shape.Id; }
        static void ValidateSource(dynamic shape) {
            int type=(int)shape.Type;
            if(type!=17 && type!=14 && type!=1) throw new InvalidOperationException("일반 텍스트 상자를 선택하세요. 그룹·표·SmartArt는 지원하지 않습니다.");
            if((int)shape.HasTextFrame!= -1 || (int)shape.TextFrame2.Orientation!=1 || Math.Abs((double)shape.Rotation)>0.01)
                throw new InvalidOperationException("회전 없는 가로 텍스트만 지원합니다.");
            if((int)shape.Fill.Visible!=0 && (double)shape.Fill.Transparency<0.999)
                throw new InvalidOperationException("배경 채우기가 있는 텍스트 상자는 지원하지 않습니다. 투명 배경 텍스트 상자를 사용하세요.");
            if(((string)shape.TextFrame2.TextRange.Text).Length>16000) throw new InvalidOperationException("텍스트 상자당 16,000자 이하로 나눠 주세요.");
        }
        public void ApplySelection(HighlightStyle style) {
            dynamic selection=app.ActiveWindow.Selection;
            if((int)selection.Type!=3 || (int)selection.TextRange2.Length==0) throw new InvalidOperationException("텍스트 상자 안에서 강조할 글자 일부를 드래그하세요.");
            if((bool)selection.HasChildShapeRange) throw new InvalidOperationException("그룹 내부 텍스트는 지원하지 않습니다.");
            dynamic shape=selection.ShapeRange.Item(1), slide=app.ActiveWindow.View.Slide;
            ApplyRange(slide,shape,(int)selection.TextRange2.Start-1,(int)selection.TextRange2.Length,style);
        }
        public void ApplyRange(object slideObject,object shapeObject,int start,int length,HighlightStyle style) { if(busy)return;busy=true;try{ApplyRangeCore(slideObject,shapeObject,start,length,style);}finally{busy=false;} }
        void ApplyRangeCore(object slideObject,object shapeObject,int start,int length,HighlightStyle style) {
            if(disposed) throw new ObjectDisposedException("HighlightEngine");
            dynamic slide=slideObject, shape=shapeObject;
            ValidateSource(shape); style.Validate();
            string text=(string)shape.TextFrame2.TextRange.Text;
            if(start<0||length<=0||(long)start+length>text.Length) throw new ArgumentException("적용할 글자를 선택하세요.");
            ShapeState state;
            try{state=GetState((object)shape);}
            catch(Exception ex){if(!MetadataError(ex))throw;state=new ShapeState{Text=text};}
            Advance(slide,shape,state,text);
            state.Marks.RemoveAll(m=>m.Length==0 || m.Ambiguous || (m.Start<start+length && m.Start+m.Length>start));
            if(state.Marks.Count>=64) throw new InvalidOperationException("한 텍스트 상자에 최대 64개 범위를 지원합니다.");
            state.Marks.Add(new Mark{Start=start,Length=length,Style=style.Copy()});
            var boxes=Compute(shape,state); // Validate all geometry before mutation.
            string encoded=StateCodec.Encode(state);
            app.StartNewUndoEntry();
            Render(slide,shape,boxes);
            shape.Tags.Add(StateTag,encoded);
            history.Remove(Identity(slide,shape)); Remember(slide,shape,state);
            Report("적용 완료 · 자동 갱신 중");
        }
        static bool MetadataError(Exception ex){return ex is InvalidDataException || ex is FormatException || ex is SerializationException || ex is ArgumentException;}
        void Remember(dynamic slide,dynamic shape,ShapeState state) {
            string key=Identity(slide,shape);
            Dictionary<string,string> items;
            if(!history.TryGetValue(key,out items)){
                if(history.Count>=256)history.Clear();
                items=new Dictionary<string,string>();history[key]=items;
            }
            if(items.Count>=24)items.Clear();
            items[state.Text]=StateCodec.Encode(state);
        }
        void Advance(dynamic slide,dynamic shape,ShapeState state,string text) {
            if(state.Text==text)return;
            Remember(slide,shape,state);
            Dictionary<string,string> items;string known;
            string identity=Identity(slide,shape);
            if(history.TryGetValue(identity,out items)&&items.TryGetValue(text,out known)) {
                var previous=StateCodec.Decode(known);state.Text=text;state.Marks=previous.Marks;return;
            }
            foreach(Mark m in state.Marks) {
                RangeResult mapped=RangeTracker.Map(state.Text,text,m.Start,m.Length);
                m.Start=mapped.Start;m.Length=mapped.Length;m.Ambiguous=m.Ambiguous||mapped.Ambiguous;
            }
            state.Text=text;
        }
        sealed class Box { public string Key;public double X,Y,W,H; public HighlightStyle Style; }
        static List<Box> Compute(dynamic shape,ShapeState state) {
            var result=new List<Box>();
            dynamic full=shape.TextFrame2.TextRange;
            int count=(int)full.Lines().Count;
            foreach(Mark mark in state.Marks) {
                if(mark.Length==0||mark.Ambiguous)continue;
                int index=0;
                for(int lineIndex=1;lineIndex<=count;lineIndex++) {
                    dynamic line=full.Lines(lineIndex,1);
                    int a=Math.Max(mark.Start,(int)line.Start-1),b=Math.Min(mark.Start+mark.Length,(int)line.Start-1+(int)line.Length);
                    while(b>a && (state.Text[b-1]=='\r'||state.Text[b-1]=='\n'||state.Text[b-1]=='\v'))b--;
                    if(a>=b)continue;
                    dynamic range=full.Characters(a+1,b-a);
                    var s=mark.Style;
                    double width=(double)range.BoundWidth+s.Left+s.Right,height=(double)range.BoundHeight+s.Top+s.Bottom;
                    if(width<0.2||height<0.2)throw new InvalidOperationException("음수 여백이 너무 큽니다. 하이라이트 크기는 0보다 커야 합니다.");
                    result.Add(new Box{Key=mark.Id+":"+(index++).ToString(CultureInfo.InvariantCulture),X=(double)range.BoundLeft-s.Left,Y=(double)range.BoundTop-s.Top,W=width,H=height,Style=s});
                }
            }
            return result;
        }
        static void SetGeometry(dynamic shape,Box b) {
            if(Math.Abs((double)shape.Left-b.X)>0.03)shape.Left=(float)b.X;
            if(Math.Abs((double)shape.Top-b.Y)>0.03)shape.Top=(float)b.Y;
            if(Math.Abs((double)shape.Width-b.W)>0.03)shape.Width=(float)b.W;
            if(Math.Abs((double)shape.Height-b.H)>0.03)shape.Height=(float)b.H;
            if((int)shape.Visible!=-1)shape.Visible=-1;
            if((int)shape.Fill.Type!=1)shape.Fill.Solid();
            if((int)shape.Fill.Visible!=-1)shape.Fill.Visible=-1;
            if((int)shape.Fill.ForeColor.RGB!=b.Style.Rgb)shape.Fill.ForeColor.RGB=b.Style.Rgb;
            if(Math.Abs((double)shape.Fill.Transparency-b.Style.Transparency)>0.0001)shape.Fill.Transparency=(float)b.Style.Transparency;
            if((int)shape.Line.Visible!=0)shape.Line.Visible=0;
        }
        static void Render(dynamic slide,dynamic source,List<Box> boxes) {
            string owner=((int)source.Id).ToString(CultureInfo.InvariantCulture);
            var existing=new Dictionary<string,object>();
            for(int i=(int)slide.Shapes.Count;i>=1;i--) {
                dynamic candidate=slide.Shapes.Item(i);
                if(Tag(candidate,OwnerTag)!=owner)continue;
                string key=Tag(candidate,KeyTag);
                if(existing.ContainsKey(key))candidate.Delete();else existing.Add(key,(object)candidate);
            }
            // Each box belongs to one owner and one mark; unrelated slide objects are untouched.
            var ordered=new List<object>();
            foreach(Box box in boxes) {
                object old; dynamic rect;
                if(existing.TryGetValue(box.Key,out old)){rect=old;existing.Remove(box.Key);}
                else {
                    rect=slide.Shapes.AddShape(1,(float)box.X,(float)box.Y,(float)box.W,(float)box.H);
                    rect.Name="PPT Highlighter "+owner+" "+box.Key;
                    rect.Tags.Add(OwnerTag,owner);rect.Tags.Add(KeyTag,box.Key);
                    rect.AlternativeText="Text highlight / 텍스트 강조";
                }
                SetGeometry(rect,box);
                ordered.Add((object)rect);
            }
            foreach(object item in existing.Values)((dynamic)item).Delete();
            dynamic anchor=source;
            for(int i=ordered.Count-1;i>=0;i--) {
                dynamic rect=ordered[i];int limit=(int)slide.Shapes.Count+1;
                while((int)rect.ZOrderPosition!=(int)anchor.ZOrderPosition-1 && limit-->0)
                    rect.ZOrder((int)rect.ZOrderPosition>(int)anchor.ZOrderPosition?3:2);
                anchor=rect;
            }
        }
        public void SyncSlide(object slideObject) {
            if(disposed||busy)return;
            busy=true;
            try {
                dynamic slide=slideObject;
                var sources=new List<object>();var validOwners=new HashSet<string>();
                for(int i=1;i<=(int)slide.Shapes.Count;i++) {
                    dynamic shape=slide.Shapes.Item(i);
                    if(Tag(shape,StateTag).Length>0){sources.Add((object)shape);validOwners.Add(((int)shape.Id).ToString(CultureInfo.InvariantCulture));}
                }
                int ambiguous=0,unsupported=0;string lastIssue="";
                foreach(object source in sources) {
                    dynamic shape=source;
                    try {
                        ValidateSource(shape);
                        ShapeState state=GetState((object)shape);
                        Advance(slide,shape,state,(string)shape.TextFrame2.TextRange.Text);
                        var boxes=Compute(shape,state);
                        Render(slide,shape,boxes);
                        string encoded=StateCodec.Encode(state);
                        if(Tag(shape,StateTag)!=encoded)shape.Tags.Add(StateTag,encoded);
                        if(state.Marks.Any(m=>m.Ambiguous))ambiguous++;
                    } catch(Exception ex) {
                        if(!(ex is InvalidOperationException)&&!MetadataError(ex))throw;
                        HideOwned(slide,shape);unsupported++;lastIssue=MetadataError(ex)?"연결 정보가 손상되었습니다. 글자를 다시 선택하고 적용하세요.":ex.Message;
                    }
                }
                for(int i=(int)slide.Shapes.Count;i>=1;i--) {
                    dynamic candidate=slide.Shapes.Item(i);string owner=Tag(candidate,OwnerTag);
                    if(owner.Length>0&&!validOwners.Contains(owner)&&Tag(candidate,KeyTag).Length>0)candidate.Delete();
                }
                if(unsupported>0)Report(unsupported+"개 객체 확인 필요 · "+lastIssue);
                else if(ambiguous>0)Report("범위를 확정할 수 없어 강조를 숨겼습니다. 글자를 다시 선택하고 적용하세요.");
                else Report("자동 갱신 중 · 저장된 강조는 플러그인 없이 표시됩니다.");
            } finally {busy=false;}
        }
        static void HideOwned(dynamic slide,dynamic source) {
            string owner=((int)source.Id).ToString(CultureInfo.InvariantCulture);
            for(int i=1;i<=(int)slide.Shapes.Count;i++) {
                dynamic shape=slide.Shapes.Item(i);
                if(Tag(shape,OwnerTag)==owner && Tag(shape,KeyTag).Length>0 && (int)shape.Visible!=0)shape.Visible=0;
            }
        }
        public void SyncActive() {
            if(disposed)return;
            if((int)app.Presentations.Count==0 || (int)app.Windows.Count==0)return;
            if((int)app.ActiveWindow.ViewType!=9 && (int)app.ActiveWindow.ViewType!=1)return;
            SyncSlide(app.ActiveWindow.View.Slide);
        }
        public void SyncPresentation(object presentation) {
            dynamic pres=presentation;
            for(int i=1;i<=(int)pres.Slides.Count;i++)SyncSlide(pres.Slides.Item(i));
        }
        public void Refresh() { SyncPresentation(app.ActivePresentation); }
        public void RemoveSelection() { if(busy)return;busy=true;try{RemoveSelectionCore();}finally{busy=false;} }
        void RemoveSelectionCore() {
            dynamic selection=app.ActiveWindow.Selection,slide=app.ActiveWindow.View.Slide;
            if((int)selection.Type!=3 && (int)selection.Type!=2)throw new InvalidOperationException("강조한 글자 또는 텍스트 상자를 선택하세요.");
            dynamic shape=selection.ShapeRange.Item(1);
            string owner=Tag(shape,OwnerTag);
            if(owner.Length>0)throw new InvalidOperationException("하이라이트 도형 대신 원래 글자를 선택하세요.");
            if(Tag(shape,StateTag).Length==0){Report("선택한 텍스트에 관리 중인 강조가 없습니다.");return;}
            ShapeState state=GetState((object)shape);Advance(slide,shape,state,(string)shape.TextFrame2.TextRange.Text);
            if((int)selection.Type==3 && (int)selection.TextRange2.Length>0) {
                int a=(int)selection.TextRange2.Start-1,b=a+(int)selection.TextRange2.Length;
                state.Marks.RemoveAll(m=>m.Ambiguous||m.Length==0||(m.Start<b&&m.Start+m.Length>a));
            } else state.Marks.Clear();
            app.StartNewUndoEntry();Render(slide,shape,Compute(shape,state));
            if(state.Marks.Count==0)shape.Tags.Delete(StateTag);else shape.Tags.Add(StateTag,StateCodec.Encode(state));
            history.Remove(Identity(slide,shape));Report("강조를 제거했습니다. 원래 글자는 유지됩니다.");
        }
        public void Dispose(){disposed=true;history.Clear();app=null;}
    }
}
