﻿using System;
using System.Xml.Linq;
using System.Linq;
using PptHighlighter;
class RibbonLayoutTest {
 static int Main(){var xml=XDocument.Parse(new Connect().GetCustomUI("Microsoft.PowerPoint"));XNamespace ns="http://schemas.microsoft.com/office/2009/07/customui";int groups=xml.Descendants(ns+"group").Count();int edits=xml.Descendants(ns+"editBox").Count();bool popup=xml.Descendants().Any(x=>(string)x.Attribute("onAction")=="OpenSettings");Console.WriteLine("Groups="+groups+"; Edits="+edits+"; SettingsPopup="+popup);return groups>=5&&edits==4&&!popup?0:1;}
}
