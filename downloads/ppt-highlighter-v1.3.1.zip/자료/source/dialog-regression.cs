using System;
using System.Reflection;
using System.Windows.Forms;
class DialogRegression {
 [STAThread]static int Main(string[] args){var a=Assembly.LoadFrom(args[0]);var t=a.GetType("PptHighlighter.CustomColorDialog",true);using(var f=(Form)Activator.CreateInstance(t,BindingFlags.Instance|BindingFlags.NonPublic,null,new object[]{0x65E8FF},null)){bool ok=f.Controls.Find("colorTabs",true).Length==1&&f.Controls.Find("newColor",true).Length==1&&f.Controls.Find("currentColor",true).Length==1;Console.WriteLine(ok?"PASS Office-style dialog tabs and comparison":"FAIL Office-style dialog tabs and comparison");return ok?0:1;}}
}
