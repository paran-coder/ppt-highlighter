using System;
using System.Drawing;
using System.Reflection;
class PositionRegression {
 static int Main(string[] args){var a=Assembly.LoadFrom(args[0]);var t=a.GetType("PptHighlighter.DialogPlacement");if(t==null){Console.WriteLine("FAIL no owner-relative dialog positioning");return 1;}var m=t.GetMethod("Center");var p=(Point)m.Invoke(null,new object[]{new Rectangle(100,100,1200,800),new Rectangle(0,0,1920,1080),new Size(340,400)});if(p!=new Point(530,300))return 1;p=(Point)m.Invoke(null,new object[]{new Rectangle(-1920,0,1920,1080),new Rectangle(-1920,0,1920,1040),new Size(340,400)});if(p!=new Point(-1130,340))return 1;p=(Point)m.Invoke(null,new object[]{new Rectangle(0,0,100,100),new Rectangle(0,0,300,200),new Size(340,400)});if(p!=Point.Empty)return 1;Console.WriteLine("PASS owner centering, negative monitor, work-area clipping");return 0;}
}
