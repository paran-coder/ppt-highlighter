using System;
using System.Linq;
using System.Xml.Linq;
using PptHighlighter;
class PaletteRegression {
 static int Main(){var c=new Connect();var x=XDocument.Parse(c.GetCustomUI("Microsoft.PowerPoint"));XNamespace n="http://schemas.microsoft.com/office/2009/07/customui";bool ok=x.Descendants(n+"gallery").Any(e=>(string)e.Attribute("id")=="phColor"&&(string)e.Attribute("getImage")=="GetColorIcon"&&(string)e.Attribute("getItemImage")=="GetColorImage")&&!x.Descendants(n+"editBox").Any(e=>(string)e.Attribute("id")=="phHex")&&x.Descendants(n+"button").Any(e=>(string)e.Attribute("onAction")=="MoreColors")&&x.Descendants(n+"button").Any(e=>(string)e.Attribute("onAction")=="PickColor");Console.WriteLine(ok?"PASS icon gallery, custom colors, eyedropper, no external HEX":"FAIL icon gallery, custom colors, eyedropper, no external HEX");return ok?0:1;}
}
