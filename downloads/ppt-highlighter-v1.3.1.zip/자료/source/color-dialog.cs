﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace PptHighlighter {
 public static class ColorSpace {
  public static Color Hsv(double h,double s,double v){h=((h%360)+360)%360;s=Math.Max(0,Math.Min(1,s));v=Math.Max(0,Math.Min(1,v));double c=v*s,x=c*(1-Math.Abs((h/60)%2-1)),m=v-c;double r=0,g=0,b=0;if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}return Color.FromArgb((int)Math.Round((r+m)*255),(int)Math.Round((g+m)*255),(int)Math.Round((b+m)*255));}
  public static void ToHsv(Color c,out double h,out double s,out double v){h=c.GetHue();double max=Math.Max(c.R,Math.Max(c.G,c.B)),min=Math.Min(c.R,Math.Min(c.G,c.B));v=max/255;s=max==0?0:(max-min)/max;}
 }
 internal sealed class Honeycomb:Control {
  sealed class Cell {internal PointF[] Points;internal Color Color;}
  readonly List<Cell> cells=new List<Cell>();internal Color Selected;internal event Action<Color> Changed;
  internal Honeycomb(){DoubleBuffered=true;Size=new Size(215,280);TabStop=true;AccessibleName="기본 색상표";int radius=6;float size=8.7f;for(int q=-radius;q<=radius;q++)for(int r=Math.Max(-radius,-q-radius);r<=Math.Min(radius,-q+radius);r++){float x=106+(float)(Math.Sqrt(3)*size*(q+r/2.0)),y=117+size*1.5f*r;double distance=Math.Sqrt(q*q+q*r+r*r)/radius;double hue=(Math.Atan2(y-117,x-106)*180/Math.PI+360)%360;Add(x,y,size,ColorSpace.Hsv(hue,Math.Min(1,distance),1-.28*Math.Max(0,distance-.55)));}for(int i=0;i<10;i++){int gray=255-(int)Math.Round(i*255.0/9);Add(23+i*18.5f,235,10,Color.FromArgb(gray,gray,gray));}}
  void Add(float x,float y,float size,Color color){var points=new PointF[6];for(int i=0;i<6;i++){double angle=(60*i-30)*Math.PI/180;points[i]=new PointF(x+(float)Math.Cos(angle)*size,y+(float)Math.Sin(angle)*size);}cells.Add(new Cell{Points=points,Color=color});}
  protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;foreach(Cell c in cells){using(Brush brush=new SolidBrush(c.Color))e.Graphics.FillPolygon(brush,c.Points);if(c.Color.ToArgb()==Selected.ToArgb()){using(Pen outer=new Pen(Color.Black,3))e.Graphics.DrawPolygon(outer,c.Points);using(Pen inner=new Pen(Color.White,1))e.Graphics.DrawPolygon(inner,c.Points);}}}
  protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);Focus();foreach(Cell c in cells){using(GraphicsPath path=new GraphicsPath()){path.AddPolygon(c.Points);if(path.IsVisible(e.Location)){Selected=c.Color;Invalidate();if(Changed!=null)Changed(c.Color);return;}}}}
  protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);int index=cells.FindIndex(c=>c.Color.ToArgb()==Selected.ToArgb());if(e.KeyCode==Keys.Right||e.KeyCode==Keys.Down)index++;else if(e.KeyCode==Keys.Left||e.KeyCode==Keys.Up)index--;else return;index=Math.Max(0,Math.Min(cells.Count-1,index));Selected=cells[index].Color;Invalidate();if(Changed!=null)Changed(Selected);e.Handled=true;}
  protected override bool IsInputKey(Keys key){return key==Keys.Left||key==Keys.Right||key==Keys.Up||key==Keys.Down||base.IsInputKey(key);}
 }
 internal sealed class Spectrum:Control {
  internal double Hue,Saturation,Value=1;internal bool Brightness;internal event Action Changed;Bitmap bitmap;double lastValue=-1;Size lastSize;
  internal Spectrum(){DoubleBuffered=true;TabStop=true;AccessibleName="색상 스펙트럼";}
  protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);if(Width<1||Height<1)return;if(bitmap==null||lastValue!=Value||lastSize!=Size||Brightness){if(bitmap!=null)bitmap.Dispose();bitmap=new Bitmap(Width,Height);for(int y=0;y<Height;y++)for(int x=0;x<Width;x++)bitmap.SetPixel(x,y,Brightness?ColorSpace.Hsv(Hue,Saturation,1-y/(double)Math.Max(1,Height-1)):ColorSpace.Hsv(x*360.0/Math.Max(1,Width-1),1-y/(double)Math.Max(1,Height-1),Value));lastValue=Value;lastSize=Size;}e.Graphics.DrawImageUnscaled(bitmap,0,0);int px=(int)(Hue/360*(Width-1)),py=(int)((1-Saturation)*(Height-1));if(Brightness){py=(int)((1-Value)*(Height-1));e.Graphics.DrawLine(Pens.White,0,py,Width,py);e.Graphics.DrawLine(Pens.Black,0,Math.Min(Height-1,py+1),Width,Math.Min(Height-1,py+1));}else{e.Graphics.DrawEllipse(Pens.Black,px-4,py-4,8,8);e.Graphics.DrawEllipse(Pens.White,px-3,py-3,6,6);}}
  void UpdatePoint(Point p){if(Brightness)Value=1-Math.Max(0,Math.Min(Height-1,p.Y))/(double)Math.Max(1,Height-1);else{Hue=Math.Max(0,Math.Min(Width-1,p.X))*359.999/Math.Max(1,Width-1);Saturation=1-Math.Max(0,Math.Min(Height-1,p.Y))/(double)Math.Max(1,Height-1);}Invalidate();if(Changed!=null)Changed();}
  protected override void OnMouseDown(MouseEventArgs e){base.OnMouseDown(e);if(e.Button==MouseButtons.Left){Focus();Capture=true;UpdatePoint(e.Location);}}
  protected override void OnMouseMove(MouseEventArgs e){base.OnMouseMove(e);if(Capture&&e.Button==MouseButtons.Left)UpdatePoint(e.Location);}
  protected override void OnMouseUp(MouseEventArgs e){base.OnMouseUp(e);Capture=false;}
  protected override bool IsInputKey(Keys key){return key==Keys.Left||key==Keys.Right||key==Keys.Up||key==Keys.Down||base.IsInputKey(key);}
  protected override void OnKeyDown(KeyEventArgs e){base.OnKeyDown(e);if(Brightness){if(e.KeyCode==Keys.Up)Value=Math.Min(1,Value+.01);else if(e.KeyCode==Keys.Down)Value=Math.Max(0,Value-.01);else return;}else{if(e.KeyCode==Keys.Left)Hue=(Hue+359)%360;else if(e.KeyCode==Keys.Right)Hue=(Hue+1)%360;else if(e.KeyCode==Keys.Up)Saturation=Math.Min(1,Saturation+.01);else if(e.KeyCode==Keys.Down)Saturation=Math.Max(0,Saturation-.01);else return;}Invalidate();if(Changed!=null)Changed();e.Handled=true;}
  protected override void Dispose(bool disposing){if(disposing&&bitmap!=null){bitmap.Dispose();bitmap=null;}base.Dispose(disposing);}
 }
 internal sealed class CustomColorDialog:Form {
  readonly Font entryFont=new Font("Segoe UI",9);
  TextBox hex;NumericUpDown red,green,blue;Panel preview;Button accept;Honeycomb honey;Spectrum spectrum,brightness;bool syncing;int selected;internal int Selected{get{return selected;}}
  internal CustomColorDialog(int initial){Text="색";ClientSize=new Size(332,365);Font=new Font("맑은 고딕",9);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;ShowInTaskbar=false;
   var tabs=new TabControl{Name="colorTabs",Location=new Point(8,10),Size=new Size(226,345)};var basic=new TabPage("기본");var custom=new TabPage("사용자 지정");tabs.TabPages.Add(basic);tabs.TabPages.Add(custom);Controls.Add(tabs);
   basic.Controls.Add(new Label{Text="색(C):",Location=new Point(6,9),AutoSize=true});honey=new Honeycomb{Location=new Point(0,20)};basic.Controls.Add(honey);honey.Changed+=delegate(Color color){SelectColor(color);};
   custom.Controls.Add(new Label{Text="색(C):",Location=new Point(6,9),AutoSize=true});spectrum=new Spectrum{Name="spectrum",Location=new Point(9,29),Size=new Size(170,155)};brightness=new Spectrum{Name="brightness",Brightness=true,Location=new Point(190,29),Size=new Size(13,155)};custom.Controls.Add(spectrum);custom.Controls.Add(brightness);
   spectrum.Changed+=delegate{SelectHsv(spectrum.Hue,spectrum.Saturation,spectrum.Value);};brightness.Changed+=delegate{SelectHsv(brightness.Hue,brightness.Saturation,brightness.Value);};
   custom.Controls.Add(new Label{Text="색 모델(D): RGB",Location=new Point(7,197),AutoSize=true});red=Channel(custom,"빨강(R):",220);green=Channel(custom,"녹색(G):",246);blue=Channel(custom,"파랑(B):",272);
   custom.Controls.Add(new Label{Text="16진수(H):",Location=new Point(7,301),AutoSize=true});hex=new TextBox{Name="hex",Location=new Point(84,297),Size=new Size(105,24),MaxLength=7,Font=entryFont,ImeMode=ImeMode.Disable};custom.Controls.Add(hex);
   accept=new Button{Text="확인",Location=new Point(245,12),Size=new Size(79,27),DialogResult=DialogResult.OK};var cancel=new Button{Text="취소",Location=new Point(245,47),Size=new Size(79,27),DialogResult=DialogResult.Cancel};Controls.Add(accept);Controls.Add(cancel);AcceptButton=accept;CancelButton=cancel;
   Controls.Add(new Label{Text="새 색",Location=new Point(257,262),AutoSize=true});preview=new Panel{Name="newColor",Location=new Point(257,284),Size=new Size(59,28),BorderStyle=BorderStyle.FixedSingle};Controls.Add(preview);Controls.Add(new Panel{Name="currentColor",BackColor=PaletteColor.FromOffice(initial),Location=new Point(257,312),Size=new Size(59,28),BorderStyle=BorderStyle.FixedSingle});Controls.Add(new Label{Text="현재 색",Location=new Point(257,343),AutoSize=true});
   red.ValueChanged+=ChannelsChanged;green.ValueChanged+=ChannelsChanged;blue.ValueChanged+=ChannelsChanged;hex.TextChanged+=delegate{if(syncing)return;int value;bool valid=PaletteColor.TryHex(hex.Text,out value);accept.Enabled=valid;if(valid)SelectColor(PaletteColor.FromOffice(value));};SelectColor(PaletteColor.FromOffice(initial));
  }
  NumericUpDown Channel(Control parent,string label,int y){parent.Controls.Add(new Label{Text=label,Location=new Point(7,y+3),AutoSize=true});var input=new NumericUpDown{Location=new Point(84,y),Size=new Size(68,24),Minimum=0,Maximum=255,Font=entryFont,ImeMode=ImeMode.Disable};foreach(Control child in input.Controls)child.ImeMode=ImeMode.Disable;parent.Controls.Add(input);return input;}
  protected override void Dispose(bool disposing){base.Dispose(disposing);if(disposing)entryFont.Dispose();}
  void ChannelsChanged(object sender,EventArgs e){if(!syncing)SelectColor(Color.FromArgb((int)red.Value,(int)green.Value,(int)blue.Value));}
  void SelectHsv(double h,double s,double v){SelectColor(ColorSpace.Hsv(h,s,v));spectrum.Hue=brightness.Hue=h;spectrum.Saturation=brightness.Saturation=s;spectrum.Value=brightness.Value=v;spectrum.Invalidate();brightness.Invalidate();}
  void SelectColor(Color color){syncing=true;try{selected=PaletteColor.ToOffice(color);red.Value=color.R;green.Value=color.G;blue.Value=color.B;hex.Text=PaletteColor.Hex(selected);preview.BackColor=color;honey.Selected=color;honey.Invalidate();double h,s,v;ColorSpace.ToHsv(color,out h,out s,out v);spectrum.Hue=brightness.Hue=h;spectrum.Saturation=brightness.Saturation=s;spectrum.Value=brightness.Value=v;spectrum.Invalidate();brightness.Invalidate();accept.Enabled=true;}finally{syncing=false;}}
 }
}
