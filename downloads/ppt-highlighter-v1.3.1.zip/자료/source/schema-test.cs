﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using PptHighlighter;
class SchemaTest {
 static int Main(string[] args){int errors=0;var settings=new XmlReaderSettings();settings.Schemas.Add("http://schemas.microsoft.com/office/2009/07/customui",args[0]);settings.ValidationType=ValidationType.Schema;settings.ValidationEventHandler+=(s,e)=>{errors++;Console.WriteLine(e.Message);};string xml=new Connect().GetCustomUI("Microsoft.PowerPoint");using(var reader=XmlReader.Create(new StringReader(xml),settings)){while(reader.Read()){} }if(args.Length>1)File.WriteAllText(args[1],xml);Console.WriteLine("Schema errors="+errors);return errors==0?0:1;}
}
