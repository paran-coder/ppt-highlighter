using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
namespace PptHighlighter {
 public static class DialogPlacement {
  public static Point Center(Rectangle owner,Rectangle work,Size size){int x=owner.Left+(owner.Width-size.Width)/2,y=owner.Top+(owner.Height-size.Height)/2;return new Point(Math.Max(work.Left,Math.Min(x,Math.Max(work.Left,work.Right-size.Width))),Math.Max(work.Top,Math.Min(y,Math.Max(work.Top,work.Bottom-size.Height))));}
 }
 internal sealed class PptOwner:IWin32Window {
  public IntPtr Handle{get;private set;}
  [StructLayout(LayoutKind.Sequential)]struct Rect{internal int Left,Top,Right,Bottom;}
  delegate bool EnumProc(IntPtr hwnd,IntPtr data);
  [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")]static extern IntPtr GetAncestor(IntPtr hwnd,uint flags);
  [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr hwnd,out uint pid);
  [DllImport("user32.dll")]static extern bool EnumWindows(EnumProc callback,IntPtr data);
  [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr hwnd,StringBuilder name,int count);
  [DllImport("user32.dll")]static extern bool GetWindowRect(IntPtr hwnd,out Rect rect);
  internal PptOwner(object app){uint process=(uint)Process.GetCurrentProcess().Id,pid;IntPtr foreground=GetAncestor(GetForegroundWindow(),3);GetWindowThreadProcessId(foreground,out pid);if(pid==process&&IsWindowVisible(foreground))Handle=foreground;else EnumWindows(delegate(IntPtr hwnd,IntPtr data){uint candidate;GetWindowThreadProcessId(hwnd,out candidate);if(candidate!=process||!IsWindowVisible(hwnd))return true;var name=new StringBuilder(256);GetClassName(hwnd,name,name.Capacity);if(name.ToString()=="PPTFrameClass"){Handle=hwnd;return false;}return true;},IntPtr.Zero);if(Handle==IntPtr.Zero)throw new InvalidOperationException("PowerPoint 소유 창을 찾을 수 없습니다.");}
  internal void Center(Form dialog){Rect rect;if(!GetWindowRect(Handle,out rect))throw new InvalidOperationException("PowerPoint 창 위치를 읽을 수 없습니다.");dialog.Location=DialogPlacement.Center(Rectangle.FromLTRB(rect.Left,rect.Top,rect.Right,rect.Bottom),Screen.FromHandle(Handle).WorkingArea,dialog.Size);}
 }
}
