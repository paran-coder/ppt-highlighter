﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Win32;

static class Installation {
    public const string Version="1.3.1",ProgId="PptHighlighter.Connect",ClassId="{1843BF91-D536-4B15-B6D0-9F481CD70E54}";
    const string Owner="PptHighlighterOwner";
    public static readonly string Base=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"PptHighlighter");
    public static readonly string Folder=Path.Combine(Base,Version),Dll=Path.Combine(Folder,"ppt-highlighter-v1.3.1.dll");
    static readonly string Manifest=Path.Combine(Base,"installation.xml"),Uninstaller=Path.Combine(Base,"Uninstall.exe");
    static readonly string[] Keys={@"Software\Classes\CLSID\"+ClassId,@"Software\Classes\"+ProgId,@"Software\Microsoft\Office\PowerPoint\Addins\"+ProgId,@"Software\Microsoft\Windows\CurrentVersion\Uninstall\PptHighlighter"};
    static string Hash(byte[] value){using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(value)).Replace("-","");}
    static string HashFile(string file){return Hash(File.ReadAllBytes(file));}
    static void NoPowerPoint(){if(Process.GetProcessesByName("POWERPNT").Length!=0)throw new InvalidOperationException("열려 있는 PowerPoint 문서를 저장하고 PowerPoint를 종료한 뒤 다시 시도하세요.");}
    static void SafePath(string path){
        string full=Path.GetFullPath(path),prefix=Path.GetFullPath(Base).TrimEnd('\\')+"\\";
        if(!full.Equals(Path.GetFullPath(Base),StringComparison.OrdinalIgnoreCase)&&!full.StartsWith(prefix,StringComparison.OrdinalIgnoreCase))throw new IOException("설치 폴더 밖의 경로는 변경할 수 없습니다.");
        for(string current=full;current!=null&&current.StartsWith(Path.GetFullPath(Base),StringComparison.OrdinalIgnoreCase);current=Path.GetDirectoryName(current))
            if((Directory.Exists(current)||File.Exists(current))&&(File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("링크된 설치 경로는 지원하지 않습니다.");
    }
    public static string FindPowerPoint(){
        foreach(RegistryView view in new[]{RegistryView.Registry64,RegistryView.Registry32}){
            if(view==RegistryView.Registry64&&!Environment.Is64BitOperatingSystem)continue;
            using(var root=RegistryKey.OpenBaseKey(RegistryHive.LocalMachine,view))using(var key=root.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\POWERPNT.EXE")){
                string path=key==null?null:key.GetValue("") as string;
                if(path!=null&&File.Exists(path.Trim('"')))return path.Trim('"');
            }
        }
        foreach(string prefix in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)}){
            string path=Path.Combine(prefix,"Microsoft Office","root","Office16","POWERPNT.EXE");if(File.Exists(path))return path;
        }
        throw new InvalidOperationException("Windows 데스크톱 PowerPoint를 찾지 못했습니다.");
    }
    static RegistryView OfficeView(){using(var reader=new BinaryReader(File.OpenRead(FindPowerPoint()))){reader.BaseStream.Position=0x3C;int offset=reader.ReadInt32();reader.BaseStream.Position=offset+4;ushort machine=reader.ReadUInt16();if(machine==0x8664)return RegistryView.Registry64;if(machine==0x14C)return RegistryView.Registry32;throw new InvalidOperationException("지원하는 PowerPoint 아키텍처는 x86/x64입니다.");}}
    static byte[] Payload(){using(var resource=Assembly.GetExecutingAssembly().GetManifestResourceStream("PptHighlighter.Addin")){if(resource==null)throw new IOException("설치 파일에 추가 기능이 없습니다.");using(var memory=new MemoryStream()){resource.CopyTo(memory);return memory.ToArray();}}}
    static void RequireNoConflict(){
        CleanupRemovedInstallation();
        if(Directory.Exists(Base)||File.Exists(Base))throw new InvalidOperationException("기존 설치 폴더가 있습니다. 기존 버전을 제거한 뒤 설치하세요.");
        foreach(RegistryView view in new[]{RegistryView.Registry64,RegistryView.Registry32}){
            if(view==RegistryView.Registry64&&!Environment.Is64BitOperatingSystem)continue;
            using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,view))foreach(string path in Keys)using(var key=root.OpenSubKey(path))if(key!=null)throw new InvalidOperationException("기존 추가 기능 등록을 덮어쓰지 않습니다. 먼저 기존 설치를 제거하세요.");
        }
    }
    public static string Install(){
        NoPowerPoint();RegistryView view=OfficeView();RequireNoConflict();SafePath(Folder);
        byte[] payload=Payload();string digest=Hash(payload);bool created=false;
        try{
            Directory.CreateDirectory(Folder);created=true;File.WriteAllBytes(Dll,payload);
            File.Copy(Assembly.GetExecutingAssembly().Location,Uninstaller,false);
            var name=AssemblyName.GetAssemblyName(Dll);
            using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,view)){
                using(var cls=root.CreateSubKey(Keys[0])){
                    cls.SetValue("","PPT Highlighter");cls.SetValue(Owner,Base);
                    using(var server=cls.CreateSubKey("InprocServer32")){
                        server.SetValue("","mscoree.dll");server.SetValue("ThreadingModel","Both");server.SetValue("Class","PptHighlighter.Connect");server.SetValue("Assembly",name.FullName);server.SetValue("RuntimeVersion","v4.0.30319");server.SetValue("CodeBase",new Uri(Dll).AbsoluteUri);
                        using(var version=server.CreateSubKey("1.3.1.0")){version.SetValue("Class","PptHighlighter.Connect");version.SetValue("Assembly",name.FullName);version.SetValue("RuntimeVersion","v4.0.30319");version.SetValue("CodeBase",new Uri(Dll).AbsoluteUri);}
                    }
                    using(var prog=cls.CreateSubKey("ProgId"))prog.SetValue("",ProgId);
                    using(var category=cls.CreateSubKey(@"Implemented Categories\{62C8FE65-4EBB-45E7-B440-6E39B2CDBF29}")){}
                }
                using(var prog=root.CreateSubKey(Keys[1])){prog.SetValue("","PPT Highlighter");prog.SetValue(Owner,Base);using(var cls=prog.CreateSubKey("CLSID"))cls.SetValue("",ClassId);}
                using(var office=root.CreateSubKey(Keys[2])){office.SetValue(Owner,Base);office.SetValue("FriendlyName","PPT Highlighter");office.SetValue("Description","텍스트 하이라이트 · 투명도 · 여백");office.SetValue("LoadBehavior",3,RegistryValueKind.DWord);office.SetValue("CommandLineSafe",0,RegistryValueKind.DWord);}
                using(var uninstall=root.CreateSubKey(Keys[3])){uninstall.SetValue(Owner,Base);uninstall.SetValue("DisplayName","PPT Highlighter");uninstall.SetValue("DisplayVersion",Version);uninstall.SetValue("Publisher","PPT Highlighter");uninstall.SetValue("InstallLocation",Base);uninstall.SetValue("UninstallString","\""+Uninstaller+"\" /uninstall");uninstall.SetValue("DisplayIcon",Uninstaller);uninstall.SetValue("NoModify",1,RegistryValueKind.DWord);uninstall.SetValue("NoRepair",1,RegistryValueKind.DWord);}
            }
            new XDocument(new XElement("Installation",new XAttribute("Version",Version),new XAttribute("View",view.ToString()),new XAttribute("DllSHA256",digest),new XAttribute("UninstallerSHA256",HashFile(Uninstaller)))).Save(Manifest);
            return "설치 완료. 설치 창을 닫고 PowerPoint를 열면 '하이라이트' 탭을 사용할 수 있습니다.";
        }catch{
            using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,view))foreach(string path in Keys){using(var key=root.OpenSubKey(path)){if(key==null||(string)key.GetValue(Owner,"")!=Base)continue;}root.DeleteSubKeyTree(path,false);}
            if(created){foreach(string file in new[]{Dll,Uninstaller,Manifest})if(File.Exists(file)){SafePath(file);File.Delete(file);}if(Directory.Exists(Folder)&&Directory.GetFileSystemEntries(Folder).Length==0)Directory.Delete(Folder);if(Directory.Exists(Base)&&Directory.GetFileSystemEntries(Base).Length==0)Directory.Delete(Base);}
            throw;
        }
    }
    public static string Uninstall(){
        NoPowerPoint();SafePath(Base);
        if(!File.Exists(Manifest))throw new InvalidOperationException("이 설치 프로그램으로 설치한 기록이 없습니다.");
        XElement state=XDocument.Load(Manifest).Root;
        if((string)state.Attribute("Version")!=Version)throw new InvalidOperationException("설치 버전이 다릅니다. 해당 버전의 제거 도구를 사용하세요.");
        RegistryView view=(RegistryView)Enum.Parse(typeof(RegistryView),(string)state.Attribute("View"));
        if(File.Exists(Dll)&&HashFile(Dll)!=(string)state.Attribute("DllSHA256"))throw new IOException("설치된 DLL이 변경되어 자동 제거를 중단했습니다.");
        if(File.Exists(Uninstaller)&&HashFile(Uninstaller)!=(string)state.Attribute("UninstallerSHA256"))throw new IOException("제거 프로그램이 변경되어 자동 제거를 중단했습니다.");
        using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,view)){
            foreach(string path in Keys)using(var key=root.OpenSubKey(path))if(key!=null&&(string)key.GetValue(Owner,"")!=Base)throw new InvalidOperationException("다른 설치가 소유한 등록은 제거하지 않습니다.");
            foreach(string path in Keys)root.DeleteSubKeyTree(path,false);
        }
        if(File.Exists(Dll)){SafePath(Dll);File.Delete(Dll);}
        if(Directory.Exists(Folder)&&Directory.GetFileSystemEntries(Folder).Length==0)Directory.Delete(Folder);
        bool self=Path.GetFullPath(Assembly.GetExecutingAssembly().Location).Equals(Path.GetFullPath(Uninstaller),StringComparison.OrdinalIgnoreCase);
        if(self){new XDocument(new XElement("Removed",new XAttribute("Owner",Base),new XAttribute("Version",Version),new XAttribute("UninstallerSHA256",(string)state.Attribute("UninstallerSHA256")))).Save(Path.Combine(Base,"removed.xml"));File.Delete(Manifest);return "추가 기능 제거 완료. 이 창을 닫으세요. 제거 도구와 소유 기록 2개는 보관되며 다음 설치 때 정리됩니다.";}
        if(File.Exists(Uninstaller))File.Delete(Uninstaller);File.Delete(Manifest);
        if(Directory.GetFileSystemEntries(Base).Length==0)Directory.Delete(Base);
        return "추가 기능 제거 완료. PowerPoint를 다시 열면 하이라이트 탭이 제거됩니다.";
    }
    static void CleanupRemovedInstallation(){
        string marker=Path.Combine(Base,"removed.xml");
        if(!File.Exists(marker))return;
        SafePath(Base);SafePath(marker);SafePath(Uninstaller);
        XElement record=XDocument.Load(marker).Root;
        if(record.Name!="Removed"||(string)record.Attribute("Owner")!=Base||((string)record.Attribute("Version")!=Version&&(string)record.Attribute("Version")!="1.1.0"&&(string)record.Attribute("Version")!="1.2.0"&&(string)record.Attribute("Version")!="1.2.1"&&(string)record.Attribute("Version")!="1.3.0"))throw new IOException("기존 제거 기록의 소유 확인에 실패했습니다.");
        var files=Directory.GetFileSystemEntries(Base);
        if(files.Length!=2||!File.Exists(Uninstaller)||HashFile(Uninstaller)!=(string)record.Attribute("UninstallerSHA256"))throw new IOException("설치 폴더에 다른 파일이 있어 자동 정리를 중단했습니다.");
        if(Path.GetFullPath(Assembly.GetExecutingAssembly().Location).Equals(Path.GetFullPath(Uninstaller),StringComparison.OrdinalIgnoreCase))throw new IOException("재설치는 배포 패키지의 설치 EXE를 실행하세요.");
        foreach(RegistryView view in new[]{RegistryView.Registry64,RegistryView.Registry32}){
            if(view==RegistryView.Registry64&&!Environment.Is64BitOperatingSystem)continue;
            using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,view))foreach(string keyPath in Keys)using(var key=root.OpenSubKey(keyPath))if(key!=null)throw new IOException("기존 등록이 남아 있어 자동 정리를 중단했습니다.");
        }
        File.Delete(Uninstaller);File.Delete(marker);Directory.Delete(Base);
    }
    public static string Status(){return File.Exists(Manifest)?"설치됨 · "+Base:"설치되지 않음";}
}
class InstallerForm:Form {
    readonly Label status;
    public InstallerForm(){
        Text="PPT Highlighter 설치 · v1.3.1";ClientSize=new Size(520,320);Font=new Font("맑은 고딕",10);StartPosition=FormStartPosition.CenterScreen;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(24),ColumnCount=1,RowCount=5};Controls.Add(layout);
        layout.Controls.Add(new Label{AutoSize=true,Font=new Font(Font.FontFamily,17,FontStyle.Bold),Text="PowerPoint에 하이라이트 추가"});
        layout.Controls.Add(new Label{AutoSize=true,MaximumSize=new Size(465,75),Text="설치 후 PowerPoint 리본에서 색상·투명도·여백을 설정합니다. 자동 갱신은 PowerPoint 안에서 동작합니다."});
        layout.Controls.Add(new Label{AutoSize=true,MaximumSize=new Size(465,75),Text="설치 위치: "+Installation.Base+"\nPowerPoint를 종료한 뒤 설치 또는 제거하세요."});
        var buttons=new FlowLayoutPanel{AutoSize=true};
        foreach(string name in new[]{"설치","제거","닫기"}){var button=new Button{Text=name,AutoSize=true,Padding=new Padding(10,5,10,5)};button.Click+=delegate(object sender,EventArgs e){string action=((Button)sender).Text;if(action=="닫기"){Close();return;}try{status.Text=action=="설치"?Installation.Install():Installation.Uninstall();}catch(Exception ex){status.Text=ex.Message;}};buttons.Controls.Add(button);}layout.Controls.Add(buttons);
        status=new Label{AutoSize=true,MaximumSize=new Size(465,70),Text=Installation.Status()};layout.Controls.Add(status);
    }
}
class Installer { static void WriteReport(string[] args,string text){int i=Array.IndexOf(args,"--report");if(i>=0){if(i+1>=args.Length)throw new ArgumentException("Missing report path");using(var stream=new FileStream(args[i+1],FileMode.CreateNew,FileAccess.Write))using(var writer=new StreamWriter(stream,Encoding.UTF8))writer.WriteLine(text);}}
    [STAThread]static int Main(string[] args){
        bool silent=Array.IndexOf(args,"--silent")>=0;
        if(silent){try{string result=args[0]=="/install"?Installation.Install():args[0]=="/uninstall"?Installation.Uninstall():Installation.Status();WriteReport(args,"SUCCESS v"+Installation.Version+"\n"+result);Console.WriteLine(result);return 0;}catch(Exception ex){WriteReport(args,"ERROR v"+Installation.Version+"\n"+ex.ToString());Console.WriteLine("ERROR: "+ex.ToString());return 1;}}
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new InstallerForm());return 0;
    }
}





