﻿using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows.Forms;
namespace PptHighlighter {
 public static class PaletteColor {
  public static Color FromOffice(int rgb){return Color.FromArgb(rgb&255,(rgb>>8)&255,(rgb>>16)&255);}
  public static int ToOffice(Color color){return color.R|(color.G<<8)|(color.B<<16);}
  public static bool TryHex(string value,out int rgb){int v;rgb=0;string s=(value??"").Trim().TrimStart('#');if(s.Length!=6||!Int32.TryParse(s,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out v))return false;rgb=((v>>16)&255)|(v&0xFF00)|((v&255)<<16);return true;}
  public static string Hex(int rgb){Color c=FromOffice(rgb);return "#"+c.R.ToString("X2")+c.G.ToString("X2")+c.B.ToString("X2");}
  public static Bitmap Swatch(int rgb){Bitmap b=new Bitmap(24,24);using(Graphics g=Graphics.FromImage(b)){g.Clear(Color.Transparent);using(Brush brush=new SolidBrush(FromOffice(rgb)))g.FillRectangle(brush,2,2,20,20);g.DrawRectangle(Pens.Gray,2,2,19,19);}return b;}
  public static Bitmap Icon(int rgb){Bitmap b=new Bitmap(32,32);using(Graphics g=Graphics.FromImage(b)){g.Clear(Color.Transparent);g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;Point[] pen={new Point(8,18),new Point(21,5),new Point(26,10),new Point(13,23)};g.FillPolygon(Brushes.WhiteSmoke,pen);g.DrawPolygon(Pens.DimGray,pen);g.FillPolygon(Brushes.DimGray,new[]{new Point(8,18),new Point(6,25),new Point(13,23)});using(Brush brush=new SolidBrush(FromOffice(rgb)))g.FillRectangle(brush,3,27,26,4);}return b;}
 }
 internal sealed class PictureHost:AxHost {
  private PictureHost():base(""){}
  internal static object Convert(Image image){return GetIPictureDispFromPicture(image);}
 }
 internal sealed class ScreenColorPicker:Form {
  Bitmap capture;Rectangle area;Point point;internal int Selected{get;private set;}
  [DllImport("user32.dll")]static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
  internal static int? Pick(IWin32Window owner){IntPtr previous=IntPtr.Zero;try{try{previous=SetThreadDpiAwarenessContext(new IntPtr(-4));}catch(EntryPointNotFoundException){}using(ScreenColorPicker picker=new ScreenColorPicker()){return picker.ShowDialog(owner)==DialogResult.OK?(int?)picker.Selected:null;}}finally{if(previous!=IntPtr.Zero)SetThreadDpiAwarenessContext(previous);}}
  private ScreenColorPicker(){area=SystemInformation.VirtualScreen;capture=new Bitmap(area.Width,area.Height);try{using(Graphics g=Graphics.FromImage(capture))g.CopyFromScreen(area.Location,Point.Empty,area.Size);}catch{capture.Dispose();throw;}
   FormBorderStyle=FormBorderStyle.None;StartPosition=FormStartPosition.Manual;Bounds=area;TopMost=true;ShowInTaskbar=false;Cursor=Cursors.Cross;KeyPreview=true;DoubleBuffered=true;AutoScaleMode=AutoScaleMode.None;
   MouseMove+=delegate(object sender,MouseEventArgs e){point=e.Location;Invalidate();};
   MouseDown+=delegate(object sender,MouseEventArgs e){if(e.Button==MouseButtons.Right){DialogResult=DialogResult.Cancel;Close();}else if(e.Button==MouseButtons.Left){Selected=PaletteColor.ToOffice(capture.GetPixel(Math.Max(0,Math.Min(capture.Width-1,e.X)),Math.Max(0,Math.Min(capture.Height-1,e.Y))));DialogResult=DialogResult.OK;Close();}};
   KeyDown+=delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Escape){DialogResult=DialogResult.Cancel;Close();}};
  }
  protected override void OnPaint(PaintEventArgs e){e.Graphics.DrawImageUnscaled(capture,0,0);int x=Math.Max(0,Math.Min(capture.Width-1,point.X)),y=Math.Max(0,Math.Min(capture.Height-1,point.Y));Color color=capture.GetPixel(x,y);Rectangle tip=new Rectangle(Math.Min(x+20,Math.Max(0,Width-310)),Math.Min(y+20,Math.Max(0,Height-60)),300,50);e.Graphics.FillRectangle(Brushes.White,tip);e.Graphics.DrawRectangle(Pens.DimGray,tip);using(Brush brush=new SolidBrush(color))e.Graphics.FillRectangle(brush,tip.X+8,tip.Y+10,28,28);e.Graphics.DrawString(PaletteColor.Hex(PaletteColor.ToOffice(color))+" · 클릭 선택 / Esc 취소",SystemFonts.MessageBoxFont,Brushes.Black,tip.X+44,tip.Y+16);}
  protected override void Dispose(bool disposing){if(disposing&&capture!=null){capture.Dispose();capture=null;}base.Dispose(disposing);}
 }
}
