﻿using System;
using System.Reflection;
using System.IO;

class CoreTests {
    static int failed, passed;
    static Type tracker;
    static void Check(string name, string before, string after, int start, int length, int expectedStart, int expectedLength, bool ambiguous) {
        object r = tracker.GetMethod("Map").Invoke(null, new object[]{before,after,start,length});
        Type t = r.GetType();
        int s = (int)t.GetField("Start").GetValue(r), l = (int)t.GetField("Length").GetValue(r);
        bool a = (bool)t.GetField("Ambiguous").GetValue(r);
        bool ok = a == ambiguous && (ambiguous || (s == expectedStart && l == expectedLength));
        Console.WriteLine((ok ? "PASS " : "FAIL ") + name + " => " + s + "," + l + "," + a);
        if(ok) passed++; else failed++;
    }
    static int Main(string[] args) {
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ppt-highlighter-v1.3.1.dll");
        if(!File.Exists(path)) { Console.WriteLine("FAIL: range tracking implementation is absent"); return 1; }
        tracker = Assembly.LoadFrom(path).GetType("PptHighlighter.RangeTracker", true);
        Check("unchanged", "abcDEFxyz","abcDEFxyz",3,3,3,3,false);
        Check("insert before", "abcDEFxyz","QabcDEFxyz",3,3,4,3,false);
        Check("insert at start excluded", "abcDEFxyz","abcQDEFxyz",3,3,4,3,false);
        Check("insert inside", "abcDEFxyz","abcDQEFxyz",3,3,3,4,false);
        Check("insert at end excluded", "abcDEFxyz","abcDEFQxyz",3,3,3,3,false);
        Check("insert after", "abcDEFxyz","abcDEFxyzQ",3,3,3,3,false);
        Check("delete before", "abcDEFxyz","aDEFxyz",3,3,1,3,false);
        Check("delete inside", "abcDEFxyz","abcDFxyz",3,3,3,2,false);
        Check("delete all", "abcDEFxyz","abcxyz",3,3,3,0,false);
        Check("delete left overlap", "abcDEFxyz","abEFxyz",3,3,2,2,false);
        Check("delete right overlap", "abcDEFxyz","abcDyz",3,3,3,1,false);
        Check("replace selected", "abcDEFxyz","abcNEWxyz",3,3,3,3,false);
        Check("replace inside", "abcDEFxyz","abcD123Fxyz",3,3,3,5,false);
        Check("replace crossing selection is ambiguous", "abcDEFxyz","abNEWxyz",3,3,0,0,true);
        Check("Korean", "앞 강조 뒤","앞 큰강조 뒤",2,2,3,2,false);
        Check("emoji before", "aHELLOz","😀aHELLOz",1,5,3,5,false);
        Check("multiple edits conservative", "aHELLOz","bHELLOx",1,5,0,0,true);
        Check("repeated deletion ambiguous", "foo foo","foo",4,3,0,0,true);
        Check("empty document", "abc","",1,1,0,0,false);
        Check("empty record stays empty", "abc","aXbc",1,0,1,0,false);
        Console.WriteLine("RESULT " + passed + " passed, " + failed + " failed");
        return failed == 0 ? 0 : 1;
    }
}


