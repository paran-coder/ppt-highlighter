﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using Extensibility;
using Microsoft.Office.Core;
[assembly:AssemblyVersion("1.3.1.0")]
[assembly:AssemblyFileVersion("1.3.1.0")]
[assembly:AssemblyTitle("PPT Highlighter")]
[assembly:ComVisible(false)]
namespace PptHighlighter {
 [ComVisible(true),Guid("A8BF905F-9852-43A5-9EB6-78683B28014E"),InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
 public interface IHighlightCallbacks {
  [DispId(11)]void ApplyHighlight([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(12)]void RemoveHighlight([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(13)]void RefreshHighlights([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(14)]void RibbonLoaded([MarshalAs(UnmanagedType.IDispatch)]object ribbon);
  [DispId(22)]void ActivateRibbon();
  [DispId(30)][return:MarshalAs(UnmanagedType.BStr)]string GetValue([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(31)]void ChangeValue([MarshalAs(UnmanagedType.IDispatch)]object control,[MarshalAs(UnmanagedType.BStr)]string value);
  [DispId(32)][return:MarshalAs(UnmanagedType.BStr)]string GetColorLabel([MarshalAs(UnmanagedType.IDispatch)]object control,int index);
  [DispId(33)]int GetColorCount([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(34)]int GetSelectedColor([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(35)]void ChooseColor([MarshalAs(UnmanagedType.IDispatch)]object control,[MarshalAs(UnmanagedType.BStr)]string id,int index);
  [DispId(36)][return:MarshalAs(UnmanagedType.VariantBool)]bool GetAutomatic([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(37)]void ToggleAutomatic([MarshalAs(UnmanagedType.IDispatch)]object control,[MarshalAs(UnmanagedType.VariantBool)]bool pressed);
  [DispId(38)]void ResetDefaults([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(39)][return:MarshalAs(UnmanagedType.BStr)]string GetStatus([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(41)][return:MarshalAs(UnmanagedType.IDispatch)]object GetColorIcon([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(42)][return:MarshalAs(UnmanagedType.IDispatch)]object GetColorImage([MarshalAs(UnmanagedType.IDispatch)]object control,int index);
  [DispId(43)]void MoreColors([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(44)]void PickColor([MarshalAs(UnmanagedType.IDispatch)]object control);
  [DispId(40)]void CreateExample([MarshalAs(UnmanagedType.IDispatch)]object control);
 }
 [ComVisible(true),Guid("1843BF91-D536-4B15-B6D0-9F481CD70E54"),ProgId("PptHighlighter.Connect"),ClassInterface(ClassInterfaceType.None),ComDefaultInterface(typeof(IHighlightCallbacks))]
 public sealed class Connect:IDTExtensibility2,IRibbonExtensibility,IHighlightCallbacks {
  object app,addin,ribbon;EngineController controller;HighlightStyle style=new HighlightStyle();bool automatic=true;
  string status="글자 일부를 선택하세요";
  static readonly string[] names={"노랑","연두","하늘","분홍","주황","보라","흰색","검정","빨강","초록","파랑","청록","자홍","주황 진하게","노랑 진하게","회색","밝은 회색","짙은 회색","남색","갈색"};
  static readonly int[] colors={0x65E8FF,0x91EEA8,0xFFCDA0,0xC5ADF9,0x85C3FF,0xF1BBCE,0xFFFFFF,0x000000,0x0000FF,0x008000,0xFF0000,0xFFFF00,0xFF00FF,0x0080FF,0x00FFFF,0x808080,0xC0C0C0,0x404040,0x800000,0x2A2AA5};
  readonly Dictionary<int,object> pictures=new Dictionary<int,object>();readonly List<Bitmap> bitmaps=new List<Bitmap>();
  object Picture(int key,Bitmap bitmap){object result;if(pictures.TryGetValue(key,out result)){bitmap.Dispose();return result;}try{result=PictureHost.Convert(bitmap);pictures.Add(key,result);bitmaps.Add(bitmap);return result;}catch{bitmap.Dispose();throw;}}
  public object GetColorIcon(object control){return Picture(0x1000000|style.Rgb,PaletteColor.Icon(style.Rgb));}
  public object GetColorImage(object control,int index){return index>=0&&index<colors.Length?Picture(colors[index],PaletteColor.Swatch(colors[index])):null;}
  public void MoreColors(object control){try{PptOwner owner=new PptOwner(app);using(CustomColorDialog dialog=new CustomColorDialog(style.Rgb)){dialog.Shown+=delegate{owner.Center(dialog);};if(dialog.ShowDialog(owner)==DialogResult.OK){style.Rgb=dialog.Selected;status="색상 설정 · 적용을 누르세요";}}}catch(Exception){status="색상 선택을 다시 시도하세요";}Invalidate();}
  public void PickColor(object control){try{int? color=ScreenColorPicker.Pick(new PptOwner(app));if(color.HasValue){style.Rgb=color.Value;status="색상 설정 · 적용을 누르세요";}}catch(Exception){status="화면 색상을 읽을 수 없습니다";}Invalidate();}
  public void OnConnection(object Application,ext_ConnectMode mode,object AddInInst,ref Array custom){app=Application;addin=AddInInst;controller=new EngineController(app);controller.Enabled=automatic;}
  public void OnDisconnection(ext_DisconnectMode mode,ref Array custom){Cleanup();}
  public void OnAddInsUpdate(ref Array custom){}
  public void OnStartupComplete(ref Array custom){}
  public void OnBeginShutdown(ref Array custom){Cleanup();}
  void Cleanup(){object keepApp=app;if(controller!=null){controller.Dispose();controller=null;}ribbon=null;foreach(object picture in pictures.Values){if(Marshal.IsComObject(picture))Marshal.ReleaseComObject(picture);}pictures.Clear();foreach(Bitmap bitmap in bitmaps)bitmap.Dispose();bitmaps.Clear();addin=null;app=null;GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();GC.WaitForPendingFinalizers();GC.KeepAlive(keepApp);}
  public string GetCustomUI(string id){return @"<customUI xmlns='http://schemas.microsoft.com/office/2009/07/customui' onLoad='RibbonLoaded'>
   <ribbon><tabs><tab id='phTab' label='하이라이트'>
    <group id='phColorGroup' label='하이라이트 색상'>
     <gallery id='phColor' label='색상' size='large' columns='5' itemWidth='24' itemHeight='24' showItemLabel='false' getImage='GetColorIcon' getItemCount='GetColorCount' getItemLabel='GetColorLabel' getItemImage='GetColorImage' onAction='ChooseColor' screentip='하이라이트 색상' supertip='색상 칸을 선택하거나 다른 색과 스포이드를 사용하세요.'>
      <button id='phMoreColors' label='다른 색…' onAction='MoreColors'/>
      <button id='phEyedropper' label='스포이드' onAction='PickColor'/>
     </gallery>
    </group>
    <group id='phOpacityGroup' label='투명도'>
     <comboBox id='phTransparency' label='투명도 (%)' sizeString='100.0' getText='GetValue' onChange='ChangeValue' screentip='0~100%' supertip='0은 불투명, 100은 완전히 투명합니다. 값을 입력한 뒤 Enter를 누르세요.'>
      <item id='op0' label='0'/><item id='op25' label='25'/><item id='op35' label='35'/><item id='op50' label='50'/><item id='op75' label='75'/><item id='op100' label='100'/>
     </comboBox><labelControl id='phOpacityHint' label='0: 불투명 · 100: 투명'/>
    </group>
    <group id='phPaddingGroup' label='적용 범위 (pt)'>
     <box id='phPaddingColumns' boxStyle='horizontal'>
      <box id='phVertical' boxStyle='vertical'>
       <editBox id='phTop' label='위' sizeString='-000.0' getText='GetValue' onChange='ChangeValue'/>
       <editBox id='phBottom' label='아래' sizeString='-000.0' getText='GetValue' onChange='ChangeValue'/>
      </box><box id='phHorizontal' boxStyle='vertical'>
       <editBox id='phLeft' label='왼쪽' sizeString='-000.0' getText='GetValue' onChange='ChangeValue'/>
       <editBox id='phRight' label='오른쪽' sizeString='-000.0' getText='GetValue' onChange='ChangeValue'/>
      </box>
     </box>
    </group>
    <group id='phActions' label='선택 글자 적용'>
     <button id='phApply' label='하이라이트 적용' size='large' imageMso='FormatPainter' onAction='ApplyHighlight' screentip='선택한 글자에 적용' supertip='텍스트 상자 안에서 글자 일부를 드래그한 다음 누르세요.'/>
     <button id='phRemove' label='강조 제거' size='large' imageMso='ClearFormatting' onAction='RemoveHighlight'/>
     <button id='phRefresh' label='다시 맞추기' size='large' imageMso='RefreshAll' onAction='RefreshHighlights'/>
    </group>
    <group id='phManage' label='관리'>
     <checkBox id='phAutomatic' label='자동 갱신' getPressed='GetAutomatic' onAction='ToggleAutomatic'/>
     <button id='phReset' label='설정 초기화' onAction='ResetDefaults'/>
     <button id='phExample' label='예제 만들기' onAction='CreateExample'/>
    </group>
    <group id='phStatusGroup' label='안내'><labelControl id='phStatus' getLabel='GetStatus'/></group>
   </tab></tabs></ribbon></customUI>";}
  public void RibbonLoaded(object value){ribbon=value;}
  void Invalidate(){if(ribbon!=null)((IRibbonUI)ribbon).Invalidate();}
  static string Id(object control){return (string)((dynamic)control).Id;}
  static string Number(double value){return value.ToString("0.###",CultureInfo.InvariantCulture);}
  public string GetValue(object control){switch(Id(control)){case "phHex":return "#"+((style.Rgb&255)<<16|style.Rgb&0xFF00|(style.Rgb>>16)&255).ToString("X6");case "phTransparency":return Number(style.Transparency*100);case "phTop":return Number(style.Top);case "phBottom":return Number(style.Bottom);case "phLeft":return Number(style.Left);case "phRight":return Number(style.Right);default:return "";}}
  public void ChangeValue(object control,string value){try{
   HighlightStyle next=style.Copy();string id=Id(control);value=(value??"").Trim();
   if(id=="phHex"){string hex=value.TrimStart('#');int rgb;if(hex.Length!=6||!Int32.TryParse(hex,NumberStyles.HexNumber,CultureInfo.InvariantCulture,out rgb))throw new ArgumentException("HEX는 #FFE865 형식입니다");next.Rgb=((rgb>>16)&255)|(rgb&0xFF00)|((rgb&255)<<16);}
   else {double number;if(!Double.TryParse(value.TrimEnd('%'),NumberStyles.Float,CultureInfo.InvariantCulture,out number)||Double.IsNaN(number)||Double.IsInfinity(number))throw new ArgumentException("숫자를 입력하세요");switch(id){case "phTransparency":next.Transparency=number/100;break;case "phTop":next.Top=number;break;case "phBottom":next.Bottom=number;break;case "phLeft":next.Left=number;break;case "phRight":next.Right=number;break;default:throw new ArgumentException("알 수 없는 설정");}}
   next.Validate();style=next;status="설정 완료 · 적용을 누르세요";
  }catch(Exception){status="입력 확인: 0~100% / -72~144pt";}Invalidate();}
  public int GetColorCount(object control){return names.Length;}
  public string GetColorLabel(object control,int index){return index>=0&&index<names.Length?names[index]:"";}
  public int GetSelectedColor(object control){int i=Array.IndexOf(colors,style.Rgb);return i<0?-1:i;}
  public void ChooseColor(object control,string id,int index){if(index>=0&&index<colors.Length){style.Rgb=colors[index];status="색상 설정 · 적용을 누르세요";}Invalidate();}
  public bool GetAutomatic(object control){return automatic;}
  public void ToggleAutomatic(object control,bool pressed){automatic=pressed;if(controller!=null)controller.Enabled=pressed;status=pressed?"자동 갱신 켜짐":"자동 갱신 꺼짐";Invalidate();}
  public void ResetDefaults(object control){style=new HighlightStyle();status="기본 설정으로 초기화";Invalidate();}
  public string GetStatus(object control){return status.Length>22?status.Substring(0,21)+"…":status;}
  void Run(Action action){try{if(controller==null)throw new InvalidOperationException("추가 기능이 연결되지 않았습니다.");action();status=controller.Engine.Status;}catch(Exception ex){status="작업 확인이 필요합니다";MessageBox.Show(ex.Message,"PPT Highlighter",MessageBoxButtons.OK,MessageBoxIcon.Information);}Invalidate();}
  public void ApplyHighlight(object control){Run(delegate{controller.Engine.ApplySelection(style);});}
  public void RemoveHighlight(object control){Run(delegate{controller.Engine.RemoveSelection();});}
  public void RefreshHighlights(object control){Run(delegate{controller.Engine.Refresh();});}
  public void ActivateRibbon(){if(ribbon!=null)((IRibbonUI)ribbon).ActivateTab("phTab");}
  public void CreateExample(object control){Run(delegate{dynamic a=app;dynamic p=a.Presentations.Add(-1);dynamic slide=p.Slides.Add(1,12);dynamic text=slide.Shapes.AddTextbox(1,55,100,620,230);text.TextFrame2.TextRange.Text="문장 중 선택한 글자만 강조합니다.\r글자를 수정하거나 삭제해 보세요.";text.TextFrame2.TextRange.Font.Name="맑은 고딕";text.TextFrame2.TextRange.Font.Size=30;controller.Engine.ApplyRange(slide,text,5,6,style);text.TextFrame2.TextRange.Characters(6,6).Select();});}
 }
}


