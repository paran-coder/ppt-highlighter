﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Collections.Generic;

class IntegrationTests {
    static int passed, failed;
    static void Check(string name, bool condition) { Console.WriteLine((condition?"PASS ":"FAIL ")+name); if(condition)passed++;else failed++; }
    [STAThread] static int Main(string[] args) {
        var assembly = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"ppt-highlighter-v1.3.1.dll"));
        var type = assembly.GetType("PptHighlighter.HighlightEngine");
        if(type == null) { Console.WriteLine("FAIL: PowerPoint engine implementation is absent"); return 1; }
        string output = args.Length>0 ? Path.GetFullPath(args[0]) : Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"evidence");
        if(Directory.Exists(output)) { Console.WriteLine("Refusing to overwrite evidence directory"); return 2; }
        Directory.CreateDirectory(output);
        dynamic app = Activator.CreateInstance(Type.GetTypeFromProgID("PowerPoint.Application",true));
        dynamic pres = null;
        try {
            pres=app.Presentations.Add(-1);
            dynamic slide=pres.Slides.Add(1,12);
            dynamic shape=slide.Shapes.AddTextbox(1,65,70,560,200);
            shape.TextFrame2.TextRange.Text="앞 HELLO 뒤\r두 번째 줄 선택";
            shape.TextFrame2.TextRange.Font.Name="맑은 고딕";
            shape.TextFrame2.TextRange.Font.Size=32;
            dynamic engine=Activator.CreateInstance(type,new object[]{app});
            dynamic style=Activator.CreateInstance(assembly.GetType("PptHighlighter.HighlightStyle"));
            style.Transparency=0.4; style.Left=5; style.Right=7; style.Top=2; style.Bottom=3;
            engine.ApplyRange(slide,shape,2,5,style);
            dynamic rect=slide.Shapes.Item(1);
            Check("one highlight generated",slide.Shapes.Count==2);
            Check("actual selected range width + margins",Math.Abs((double)rect.Width-((double)shape.TextFrame2.TextRange.Characters(3,5).BoundWidth+12))<0.1);
            Check("actual selected range top - margin",Math.Abs((double)rect.Top-((double)shape.TextFrame2.TextRange.Characters(3,5).BoundTop-2))<0.1);
            Check("transparency 40 percent",Math.Abs((double)rect.Fill.Transparency-0.4)<0.001);
            Check("highlight behind original text",rect.ZOrderPosition<shape.ZOrderPosition);
            string tag=(string)shape.Tags.Item("PH_STATE_V1");
            engine.SyncSlide(slide);
            Check("stable sync does not regenerate shapes",slide.Shapes.Count==2 && tag==(string)shape.Tags.Item("PH_STATE_V1"));
            shape.TextFrame2.TextRange.Characters(1,0).InsertBefore("새 ");
            engine.SyncSlide(slide);
            dynamic state=engine.GetState(shape);
            Check("edit before moves tracked range",state.Marks[0].Start==4 && state.Marks[0].Length==5);
            shape.TextFrame2.TextRange.Characters(7,0).InsertBefore("Q");
            engine.SyncSlide(slide); state=engine.GetState(shape);
            Check("edit inside grows tracked range",state.Marks[0].Length==6);
            shape.TextFrame2.TextRange.Characters(7,1).Delete();
            engine.SyncSlide(slide); state=engine.GetState(shape);
            Check("delete inside shrinks range",state.Marks[0].Length==5);
            float oldLeft=rect.Left; shape.Left=shape.Left+40; engine.SyncSlide(slide);
            Check("box move updates geometry",Math.Abs((double)rect.Left-oldLeft-40)<0.1);
            float oldWidth=rect.Width; shape.TextFrame2.TextRange.Font.Size=40; engine.SyncSlide(slide);
            Check("font resize updates geometry",rect.Width>oldWidth);
            shape.TextFrame2.TextRange.Characters(state.Marks[0].Start+1,state.Marks[0].Length).Delete();
            engine.SyncSlide(slide);
            Check("entire selected text deletion removes rectangle",slide.Shapes.Count==1);
            shape.TextFrame2.TextRange.Text="새 앞 HELLO 뒤\r두 번째 줄 선택";
            engine.SyncSlide(slide);state=engine.GetState(shape);
            Check("restoring prior text restores tracked highlight",state.Marks[0].Length==5 && slide.Shapes.Count==2);
            // Restore text through an explicit application, then test line splitting.
            shape.TextFrame2.TextRange.Text="Transparency with editable text\r선택한 글자만 하이라이트";
            engine.ApplyRange(slide,shape,0,((string)shape.TextFrame2.TextRange.Text).Length,style);
            Check("multiline selection produces separate rectangles",slide.Shapes.Count>=3);
            int originalCount=slide.Shapes.Count;
            shape.Width=240; engine.SyncSlide(slide);
            Check("line wrapping updates rectangles",slide.Shapes.Count>originalCount);
            shape.Width=590; shape.TextFrame2.TextRange.Font.Size=30; engine.SyncSlide(slide);
            bool blocked=false;
            dynamic filled=slide.Shapes.AddTextbox(1,20,380,250,50); filled.TextFrame2.TextRange.Text="Filled textbox"; filled.Fill.Visible=-1; filled.Fill.Solid(); filled.Fill.ForeColor.RGB=0xFFFFFF;
            try { engine.ApplyRange(slide,filled,0,6,style); } catch { blocked=true; }
            Check("opaque text box blocked without changing fill",blocked && filled.Fill.Visible==-1);
            filled.Delete();
            dynamic duplicate=shape.Duplicate().Item(1); duplicate.Top=260;
            engine.SyncSlide(slide);
            Check("copied text box gets its own highlights",!String.IsNullOrEmpty((string)duplicate.Tags.Item("PH_STATE_V1")) && slide.Shapes.Count>=6);
            shape.Rotation=15;
            duplicate.TextFrame2.TextRange.Characters(1,0).InsertBefore("Q");
            engine.SyncSlide(slide);
            Check("unsupported first source does not block later source",engine.GetState(duplicate).Marks[0].Start==1);
            shape.Rotation=0;engine.SyncSlide(slide);
            string validState=(string)shape.Tags.Item("PH_STATE_V1");
            shape.Tags.Add("PH_STATE_V1","ZZ");
            duplicate.TextFrame2.TextRange.Characters(1,0).InsertBefore("R");
            bool malformedBlocked=false;try{engine.SyncSlide(slide);}catch{malformedBlocked=true;}
            Check("damaged metadata does not block later source",!malformedBlocked && engine.GetState(duplicate).Marks[0].Start==2);
            shape.Tags.Add("PH_STATE_V1",validState);engine.SyncSlide(slide);
            duplicate.Delete(); engine.SyncSlide(slide);
            Check("deleted owner cleans orphan rectangles",slide.Shapes.Count==3);
            dynamic unicode=slide.Shapes.AddTextbox(1,45,400,550,100);
            unicode.TextFrame2.TextRange.Text="😀 한글 ABC";unicode.TextFrame2.TextRange.Font.Size=26;
            Check("native range indexes use UTF16 for emoji",(int)unicode.TextFrame2.TextRange.Length=="😀 한글 ABC".Length);
            engine.ApplyRange(slide,unicode,3,2,style);
            Check("Korean selection after emoji",(string)unicode.TextFrame2.TextRange.Characters(4,2).Text=="한글");
            unicode.Delete();engine.SyncSlide(slide);
            engine.Dispose();engine=null;
            dynamic controller=Activator.CreateInstance(assembly.GetType("PptHighlighter.EngineController"),new object[]{app});
            controller.Enabled=false;
            Check("native before-save event attached",(bool)controller.EventsAttached);
            shape.Left=shape.Left+13;
            string pptx=Path.Combine(output,"highlight-demo-v1.3.1.pptx");
            pres.SaveAs(pptx,24);
            // PowerPoint's object-model SaveAs bypasses BeforeSave; native user Save fires it.
            shape.Left=shape.Left+1;
            app.CommandBars.ExecuteMso("FileSave");
            DateTime deadline=DateTime.UtcNow.AddSeconds(2);
            while(DateTime.UtcNow<deadline) {
                System.Windows.Forms.Application.DoEvents();
                if((string)controller.Engine.Status!="글자 일부를 선택하고 적용하세요." && (int)pres.Saved==-1)break;
                System.Threading.Thread.Sleep(10);
            }
            Console.WriteLine("INFO native save status: "+controller.Engine.Status+"; saved="+pres.Saved);
            dynamic firstRect=slide.Shapes.Item(1);
            Check("native before-save event refreshes geometry",Math.Abs((double)firstRect.Left-((double)shape.TextFrame2.TextRange.Lines(1,1).BoundLeft-5))<0.1);
            controller.Engine.SyncSlide(slide);
            controller.Engine.SyncSlide(slide);
            Check("no-op polling preserves saved state",(int)pres.Saved==-1);
            slide.Export(Path.Combine(output,"before-close.png"),"PNG",1280,720);
            int count=slide.Shapes.Count;
            controller.Dispose(); controller=null;
            pres.Close(); pres=null;
            pres=app.Presentations.Open(pptx,-1,0,0);
            slide=pres.Slides.Item(1);
            Check("reopen PPTX without engine retains shapes",slide.Shapes.Count==count);
            slide.Export(Path.Combine(output,"without-plugin.png"),"PNG",1280,720);
            Console.WriteLine("RESULT "+passed+" passed, "+failed+" failed");
            File.WriteAllText(Path.Combine(output,"result.txt"),"PowerPoint "+app.Version+"; "+passed+" passed, "+failed+" failed");
            return failed==0?0:1;
        } catch(Exception ex) { Console.WriteLine(ex); return 1; }
        finally { if(pres!=null){pres.Saved=-1;pres.Close();} Marshal.ReleaseComObject(app); }
    }
}


