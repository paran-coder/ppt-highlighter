using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace PptHighlighter {
    public sealed class RangeResult { public int Start, Length; public bool Ambiguous; }
    public static class RangeTracker {
        public static RangeResult Map(string before, string after, int start, int length) {
            if (before == null || after == null || start < 0 || length < 0 || start + length > before.Length)
                throw new ArgumentException("Invalid text range.");
            if (length == 0) return new RangeResult { Start = Math.Min(start, after.Length), Length = 0 };
            if (before == after) return new RangeResult { Start = start, Length = length };
            int p = 0, suffix = 0;
            while (p < before.Length && p < after.Length && before[p] == after[p]) p++;
            while (suffix < before.Length-p && suffix < after.Length-p && before[before.Length-1-suffix] == after[after.Length-1-suffix]) suffix++;
            int q = before.Length - suffix, n = after.Length - suffix - p;
            RangeResult r = MapEdit(p,q,n,start,length);
            // Different edits in one sampling interval cannot safely be treated as one replacement.
            string removed = before.Substring(p,q-p), inserted = after.Substring(p,n);
            if (removed.Length > 1 && inserted.Length > 1) {
                for (int i = 0; i + 1 < removed.Length; i++) {
                    if (inserted.IndexOf(removed.Substring(i,2), StringComparison.Ordinal) >= 0) { r.Ambiguous = true; break; }
                }
            }
            // Repeated characters/words permit multiple equally valid edit locations.
            if (n == 0 || q == p) {
                int a = p, b = q;
                while (a > 0 && ((n == 0 && before[a-1] == before[b-1]) || (q == p && after[a-1] == after[a+n-1]))) {
                    a--; b--;
                    RangeResult alternative = MapEdit(a,b,n,start,length);
                    if (alternative.Start != r.Start || alternative.Length != r.Length) r.Ambiguous = true;
                }
            }
            return r;
        }
        static RangeResult MapEdit(int p,int q,int n,int s,int len) {
            int e = s + len, delta = n - (q-p);
            if (q <= s) return new RangeResult { Start = s+delta, Length = len };
            if (p >= e) return new RangeResult { Start = s, Length = len };
            int a = Math.Min(s,p), b = e > q ? e+delta : p+n;
            return new RangeResult { Start = a, Length = Math.Max(0,b-a), Ambiguous = n>0 && (p<s || q>e) };
        }
    }

    [DataContract] public sealed class HighlightStyle {
        [DataMember] public int Rgb = 0x65E8FF; // Office RGB byte order: #FFE865.
        [DataMember] public double Transparency = 0.35;
        [DataMember] public double Top = 1, Bottom = 1, Left = 2, Right = 2;
        public HighlightStyle Copy() { return (HighlightStyle)MemberwiseClone(); }
        public void Validate() {
            if(Rgb<0 || Rgb>0xFFFFFF || Double.IsNaN(Transparency) || Transparency<0 || Transparency>1)
                throw new ArgumentException("색상 또는 투명도 값이 올바르지 않습니다.");
            foreach(double v in new[]{Top,Bottom,Left,Right})
                if(Double.IsNaN(v)||Double.IsInfinity(v)||v < -72 || v > 144) throw new ArgumentException("여백은 -72~144pt 범위여야 합니다.");
        }
    }
    [DataContract] public sealed class Mark {
        [DataMember] public string Id = Guid.NewGuid().ToString("N").ToUpperInvariant();
        [DataMember] public int Start, Length;
        [DataMember] public bool Ambiguous;
        [DataMember] public HighlightStyle Style = new HighlightStyle();
    }
    [DataContract] public sealed class ShapeState {
        [DataMember] public int Version = 1;
        [DataMember] public string Text = "";
        [DataMember] public List<Mark> Marks = new List<Mark>();
    }
    public static class StateCodec {
        public static string Encode(ShapeState state) {
            using(var ms = new MemoryStream()) {
                new DataContractJsonSerializer(typeof(ShapeState)).WriteObject(ms,state);
                if(ms.Length > 120000) throw new ArgumentException("연결 정보가 너무 큽니다. 텍스트 상자를 나눠 주세요.");
                return BitConverter.ToString(ms.ToArray()).Replace("-","");
            }
        }
        public static ShapeState Decode(string hex) {
            if(hex.Length%2!=0 || hex.Length>240000) throw new InvalidDataException("Invalid metadata length");
            byte[] bytes = new byte[hex.Length/2];
            for(int i=0;i<bytes.Length;i++) bytes[i]=Convert.ToByte(hex.Substring(i*2,2),16);
            using(var ms = new MemoryStream(bytes)) {
                var state = (ShapeState)new DataContractJsonSerializer(typeof(ShapeState)).ReadObject(ms);
                if(state.Version!=1 || state.Text==null || state.Text.Length>16000 || state.Marks==null || state.Marks.Count>64)
                    throw new InvalidDataException("Unsupported metadata");
                var ids = new HashSet<string>();
                foreach(var m in state.Marks) {
                    Guid id;
                    if(m==null || !Guid.TryParseExact(m.Id,"N",out id) || !ids.Add(m.Id) || m.Start<0 || m.Length<0 || (long)m.Start+m.Length>state.Text.Length || m.Style==null)
                        throw new InvalidDataException("Invalid highlight range");
                    m.Style.Validate();
                }
                return state;
            }
        }
    }
}
