﻿# v1.3.1 checklist
- [x] Palette regression fails on v1.2.1, passes on v1.3.1.
- [x] Core range tracking: 20 checks.
- [x] Ribbon values and boundaries: 27 checks.
- [x] Palette values, icon/swatch pixels, COM images and cleanup: 112 checks.
- [x] Installer ownership fixtures: 8 checks.
- [x] Microsoft RibbonX schema: zero errors.
- [x] Actual Explorer-context installation; installed DLL hash equals candidate.
- [x] Actual ribbon icon, dropdown palette and color underline verified.
- [x] Other colors and eyedropper interactive verification (user confirmed).
- [x] Normal PowerPoint restart (user confirmed), package byte verification recorded in project package-results.json.

Version 1.3.1: Office-style two-tab color dialog implemented by the addin; Microsoft built-in dialog is not invoked. RGB/HEX and hue/saturation/brightness controls synchronize. Original current-color preview remains unchanged until confirmation.

- [x] Two-tab dialog and HSV/RGB input checks: 229.
- [x] Owner-relative centering, negative monitor and work-area clipping regression.
- [x] RGB and HEX numeric input explicitly disable inherited Office IME state.
- [x] Candidate03 actual panel position, typing and restart acceptance (user confirmed).
