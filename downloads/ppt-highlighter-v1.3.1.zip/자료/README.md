﻿# PPT Highlighter v1.3.1
Windows 데스크톱 PowerPoint COM 추가 기능. 형광펜 아이콘의 펼침 팔레트, 다른 색/HEX 대화상자, 화면 스포이드. 선택 글자 강조, 투명도/여백 및 자동 갱신.
설치 파일은 패키지 최상위의 EXE 하나입니다. 소스와 Microsoft RibbonX 스키마는 이 자료 폴더에 있습니다.
## 소스 빌드
Windows PowerShell에서 자료/build.ps1을 실행합니다. .NET Framework 4 CSC와 설치된 Office interop 참조를 사용합니다. 새 출력 폴더만 생성하며 기존 빌드를 덮어쓰지 않습니다.
검사 실행: core-tests-v1.3.1.exe, ribbon-tests-v1.3.1.exe, palette-regression-v1.3.1.exe, palette-tests-v1.3.1.exe, ribbon-layout-test-v1.3.1.exe. schema-test-v1.3.1.exe에 customui14.xsd 경로를 전달합니다. installer-tests-v1.3.1.exe에는 새 설치 EXE와 아직 없는 검사 폴더 경로를 전달합니다.
설치 시 제품 소유 LocalAppData 폴더와 HKCU 전용 COM/PowerPoint/제거 등록만 사용합니다. 관리자 권한이나 Office 보안 설정 변경은 필요하지 않습니다.

Version 1.3.1: Office-style two-tab color dialog implemented by the addin; Microsoft built-in dialog is not invoked. RGB/HEX and hue/saturation/brightness controls synchronize. Original current-color preview remains unchanged until confirmation.
