﻿param([string]$BuildName = ('build-' + (Get-Date -Format 'HHmmssfff')))
$ErrorActionPreference = 'Stop'
if ($BuildName -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]*$') { throw 'Invalid build name' }
$destination = Join-Path $PSScriptRoot $BuildName
if (Test-Path -LiteralPath $destination) { throw 'Refusing to overwrite build' }
[void](New-Item -ItemType Directory -Path $destination)
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { $compiler = 'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe' }
$source = Join-Path $PSScriptRoot 'source'
$dll = Join-Path $destination 'ppt-highlighter-v1.3.1.dll'
$files = @('core.cs','engine.cs','ui.cs','palette.cs','color-dialog.cs','dialog-owner.cs','addin.cs') | ForEach-Object { Join-Path $source $_ }
& $compiler /nologo /target:library /optimize+ /platform:anycpu /r:Microsoft.CSharp.dll /link:C:\Windows\assembly\GAC\Extensibility\7.0.3300.0__b03f5f7f11d50a3a\extensibility.dll /link:C:\Windows\assembly\GAC_MSIL\office\15.0.0.0__71e9bce111e9429c\OFFICE.DLL /r:System.Runtime.Serialization.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll "/out:$dll" $files
if ($LASTEXITCODE -ne 0) { throw 'Add-in build failed' }
& $compiler /nologo /target:winexe /optimize+ /platform:anycpu /r:System.Xml.Linq.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll "/resource:$dll,PptHighlighter.Addin" "/out:$destination\PPT-Highlighter-Setup-v1.3.1.exe" "$source\installer.cs"
if ($LASTEXITCODE -ne 0) { throw 'Installer build failed' }
foreach ($name in @('core-tests','integration-tests','ribbon-tests','ribbon-layout-test','palette-regression','palette-tests','schema-test','installer-tests','dialog-regression','color-dialog-tests','position-regression','input-regression')) {
    & $compiler /nologo /r:Microsoft.CSharp.dll /link:C:\Windows\assembly\GAC\Extensibility\7.0.3300.0__b03f5f7f11d50a3a\extensibility.dll /link:C:\Windows\assembly\GAC_MSIL\office\15.0.0.0__71e9bce111e9429c\OFFICE.DLL /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Xml.Linq.dll /r:System.Core.dll "/r:$dll" "/out:$destination\$name-v1.3.1.exe" "$source\$name.cs"
    if ($LASTEXITCODE -ne 0) { throw "Test build failed: $name" }
}
Write-Output $destination


